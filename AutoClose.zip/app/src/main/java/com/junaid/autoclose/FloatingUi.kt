package com.junaid.autoclose

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

interface UiHost {
    fun onScanNow()
    fun onSaveShot()
}

/**
 * স্ক্রিনের উপরে ভাসমান "AC" বোতাম। চাপলে ছোট কন্ট্রোল প্যানেল খোলে।
 * Accessibility overlay হিসেবে আঁকা হয়, তাই আলাদা "Display over other apps" অনুমতি লাগে না।
 */
class FloatingUi(private val ctx: Context, private val host: UiHost) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val prefs: SharedPreferences = Prefs.of(ctx)
    private val density: Float = ctx.resources.displayMetrics.density

    private lateinit var root: LinearLayout
    private lateinit var bubble: TextView
    private lateinit var scroll: ScrollView
    private lateinit var statusView: TextView
    private lateinit var enabledSwitch: Switch
    private lateinit var params: WindowManager.LayoutParams

    private var attached = false
    private var expanded = false
    private var suppress = false
    private var warn = false

    private fun dp(v: Int): Int = (v * density).toInt()

    init {
        build()
    }

    // ---------- বাইরের জন্য ----------

    fun show() {
        if (attached) return
        try {
            wm.addView(root, params)
            attached = true
        } catch (e: Exception) {
            attached = false
        }
    }

    fun hide() {
        if (!attached) return
        try {
            wm.removeView(root)
        } catch (e: Exception) {
            // কিছু করার নেই
        }
        attached = false
    }

    fun setVisible(v: Boolean) {
        root.visibility = if (v) View.VISIBLE else View.INVISIBLE
    }

    fun setStatus(t: String) {
        statusView.text = t
    }

    fun setWarn(w: Boolean) {
        warn = w
        refreshBubble()
    }

    fun setEnabledState(on: Boolean) {
        suppress = true
        enabledSwitch.isChecked = on
        suppress = false
        refreshBubble()
    }

    /** স্ক্রিনে এই ভাসমান অংশ কোথায় আছে (স্ক্রিনশট থেকে এই জায়গা বাদ দিতে) */
    fun currentRect(): Rect? {
        if (!attached) return null
        val loc = IntArray(2)
        root.getLocationOnScreen(loc)
        return Rect(loc[0], loc[1], loc[0] + root.width, loc[1] + root.height)
    }

    // ---------- তৈরি ----------

    private fun enabledNow(): Boolean = prefs.getBoolean(Prefs.ENABLED, true)

    private fun refreshBubble() {
        val color = when {
            !enabledNow() -> "#757575"
            warn -> "#EF6C00"
            else -> "#2E7D32"
        }
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(Color.parseColor(color))
        bubble.background = bg
        bubble.alpha = 0.92f
    }

    private fun build() {
        val dm = ctx.resources.displayMetrics

        bubble = TextView(ctx)
        bubble.text = "AC"
        bubble.setTextColor(Color.WHITE)
        bubble.textSize = 14f
        bubble.typeface = Typeface.DEFAULT_BOLD
        bubble.gravity = Gravity.CENTER
        bubble.layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))

        val panel = LinearLayout(ctx)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(12), dp(10), dp(12), dp(10))
        val panelBg = GradientDrawable()
        panelBg.setColor(Color.parseColor("#F7FFFFFF"))
        panelBg.cornerRadius = dp(14).toFloat()
        panelBg.setStroke(dp(1), Color.parseColor("#33000000"))
        panel.background = panelBg

        val title = TextView(ctx)
        title.text = "Auto Close"
        title.textSize = 15f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(Color.BLACK)
        panel.addView(title)

        enabledSwitch = Switch(ctx)
        enabledSwitch.text = "অটো-ক্লিক চালু"
        enabledSwitch.setTextColor(Color.BLACK)
        enabledSwitch.isChecked = enabledNow()
        enabledSwitch.setOnCheckedChangeListener { _, checked ->
            if (!suppress) {
                prefs.edit().putBoolean(Prefs.ENABLED, checked).apply()
                refreshBubble()
            }
        }
        panel.addView(enabledSwitch)

        statusView = TextView(ctx)
        statusView.text = "এখনো স্ক্যান হয়নি"
        statusView.textSize = 11f
        statusView.setTextColor(Color.parseColor("#222222"))
        statusView.setPadding(0, dp(6), 0, dp(6))
        panel.addView(statusView)

        addSeek(panel, "সংবেদনশীলতা (মিলের সীমা)", 40, 95, 1, Prefs.THRESHOLD, 70) { "$it%" }
        addSeek(panel, "স্ক্যানের বিরতি", 500, 5000, 100, Prefs.INTERVAL, 1500) {
            String.format("%.1f সে.", it / 1000.0)
        }

        val what = TextView(ctx)
        what.text = "কী খুঁজবে:"
        what.textSize = 12f
        what.setTextColor(Color.BLACK)
        what.setPadding(0, dp(6), 0, 0)
        panel.addView(what)

        addCheck(panel, "ছোট আইকন (>>)", Prefs.G_SKIP, true)
        addCheck(panel, "বাটন (ছবি মিলিয়ে)", Prefs.G_BUTTON, true)
        addCheck(panel, "বাটন (লেখা পড়ে)", Prefs.G_OCR, true)
        addCheck(panel, "বাটনের নাম দেখে", Prefs.G_NODE, true)
        addCheck(panel, "বিল্ট-ইন × / >> / Close", Prefs.G_BUILTIN, false)
        addCheck(panel, "আমার যোগ করা আইকন", Prefs.G_USER, true)

        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        val scanBtn = Button(ctx)
        scanBtn.text = "এখনই স্ক্যান"
        scanBtn.textSize = 12f
        scanBtn.setOnClickListener { host.onScanNow() }
        val shotBtn = Button(ctx)
        shotBtn.text = "স্ক্রিনশট সেভ"
        shotBtn.textSize = 12f
        shotBtn.setOnClickListener { host.onSaveShot() }
        row.addView(scanBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(shotBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        panel.addView(row)

        val hint = TextView(ctx)
        hint.text = "AC বোতাম টেনে সরানো যায়, চাপলে প্যানেল বন্ধ হয়।"
        hint.textSize = 10f
        hint.setTextColor(Color.parseColor("#555555"))
        hint.setPadding(0, dp(4), 0, 0)
        panel.addView(hint)

        scroll = ScrollView(ctx)
        scroll.addView(panel)
        val maxH = min(dp(400), dm.heightPixels - dp(140))
        scroll.layoutParams = LinearLayout.LayoutParams(dp(290), maxH)
        scroll.visibility = View.GONE

        root = LinearLayout(ctx)
        root.orientation = LinearLayout.VERTICAL
        root.addView(bubble)
        root.addView(scroll)

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = prefs.getInt(Prefs.BUBBLE_X, dp(8))
        params.y = prefs.getInt(Prefs.BUBBLE_Y, dp(220))

        refreshBubble()
        installDrag()
    }

    private fun installDrag() {
        bubble.setOnTouchListener(object : View.OnTouchListener {
            private var startRawX = 0f
            private var startRawY = 0f
            private var startX = 0
            private var startY = 0
            private var moved = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startRawX = e.rawX
                        startRawY = e.rawY
                        startX = params.x
                        startY = params.y
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - startRawX).toInt()
                        val dy = (e.rawY - startRawY).toInt()
                        if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                        if (moved) {
                            params.x = startX + dx
                            params.y = startY + dy
                            if (attached) wm.updateViewLayout(root, params)
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (moved) {
                            prefs.edit()
                                .putInt(Prefs.BUBBLE_X, params.x)
                                .putInt(Prefs.BUBBLE_Y, params.y)
                                .apply()
                        } else {
                            toggle()
                        }
                        return true
                    }
                }
                return false
            }
        })
    }

    private fun toggle() {
        expanded = !expanded
        scroll.visibility = if (expanded) View.VISIBLE else View.GONE
        if (expanded) {
            val dm = ctx.resources.displayMetrics
            val panelH = scroll.layoutParams.height
            params.x = params.x.coerceIn(0, max(0, dm.widthPixels - dp(290)))
            params.y = params.y.coerceIn(0, max(0, dm.heightPixels - dp(48) - panelH))
        }
        if (attached) wm.updateViewLayout(root, params)
    }

    private fun addCheck(parent: LinearLayout, label: String, key: String, def: Boolean) {
        val cb = CheckBox(ctx)
        cb.text = label
        cb.textSize = 13f
        cb.setTextColor(Color.BLACK)
        cb.isChecked = prefs.getBoolean(key, def)
        cb.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(key, checked).apply()
        }
        parent.addView(cb)
    }

    private fun addSeek(
        parent: LinearLayout,
        title: String,
        minV: Int,
        maxV: Int,
        step: Int,
        key: String,
        def: Int,
        fmt: (Int) -> String
    ) {
        val label = TextView(ctx)
        label.textSize = 12f
        label.setTextColor(Color.BLACK)
        label.setPadding(0, dp(6), 0, 0)
        val cur = prefs.getInt(key, def)
        label.text = "$title: ${fmt(cur)}"

        val sb = SeekBar(ctx)
        sb.max = (maxV - minV) / step
        sb.progress = (cur - minV) / step
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = minV + p * step
                label.text = "$title: ${fmt(v)}"
                if (fromUser) prefs.edit().putInt(key, v).apply()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(label)
        parent.addView(sb)
    }
}
