package com.junaid.autoclose

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val FILE = "autoclose"

    const val ENABLED = "enabled"
    const val THRESHOLD = "threshold"          // 40..95 (শতাংশ)
    const val INTERVAL = "interval_ms"          // 500..5000
    const val DEFAULT_INTERVAL = 1000

    // মূল লক্ষ্য: "Collect Gem" লেখা (জোন ১ এবং পুরো স্ক্রিন মোডে)
    const val PHRASES = "phrases"
    const val DEFAULT_PHRASES = "collect gem"

    // জোন ২ ও ৩-এ যে লেখা খুঁজবে
    const val PHRASES2 = "phrases2"
    const val DEFAULT_PHRASES2 = "close"

    // স্মার্ট মোড: যেকোনো ক্রস / Skip / Close / Next ধরনের লেখা বা আইকন
    const val SMART = "smart_mode"
    const val SMART_WORDS = "smart_words"
    const val DEFAULT_SMART_WORDS =
        "close,skip,skip ad,skip ads,next,continue,done,dismiss,not now,no thanks,later"

    // জোন মোড: চালু থাকলে এবং কোনো জোন সেট করা থাকলে সেই জায়গাগুলোতে খোঁজে
    const val ZONE_MODE = "zone_mode"

    // শুধু এই অ্যাপগুলোতে চালানো (খালি = সব অ্যাপ)
    const val APPS = "apps_filter"

    const val BUBBLE = "bubble"
    const val BUBBLE_X = "bubble_x"
    const val BUBBLE_Y = "bubble_y"
    const val DEBUG_TOAST = "debug_toast"
    const val TEMPLATES_VERSION = "templates_version"

    fun zoneKey(i: Int): String = "zone_$i"

    fun of(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
}
