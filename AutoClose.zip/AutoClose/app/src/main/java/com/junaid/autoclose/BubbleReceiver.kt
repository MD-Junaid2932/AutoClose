package com.junaid.autoclose

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** নোটিফিকেশনে চাপলে লুকানো ভাসমান বোতাম আবার দেখায় */
class BubbleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        Prefs.of(context).edit().putBoolean(Prefs.BUBBLE, true).apply()
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(AutoCloseService.BUBBLE_NOTIF_ID)
    }
}
