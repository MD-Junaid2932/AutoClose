package com.junaid.autoclose

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Intent
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.util.Log
import android.view.Display
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.opencv.android.OpenCVLoader
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * স্ক্রিন দেখে লক্ষ্য খুঁজে বের করে এবং সেখানে ট্যাপ করে।
 *
 * জোন মোড (ডিফল্ট): ব্যবহারকারী ভাসমান প্যানেল থেকে ২–৩টা জায়গা বেছে দেয়।
 *   জোন ১: "Collect Gem" লেখা খোঁজে
 *   জোন ২, ৩: >> আইকন অথবা "Close" লেখা খোঁজে
 * জোন সেট না থাকলে বা জোন মোড বন্ধ থাকলে পুরো স্ক্রিনে খোঁজে।
 * স্মার্ট মোড (বাছা অ্যাপে): যেকোনো Close/Skip/Next/ক্রস লেখা বা আইকনে চাপে।
 */
class AutoCloseService : AccessibilityService() {

    companion object {
        private const val TAG = "AutoClose"
        private const val CLICK_COOLDOWN_MS = 1100L
        private const val EVENT_DEBOUNCE_MS = 300L
        const val BUBBLE_NOTIF_ID = 4101
        private const val CHANNEL_ID = "autoclose_bubble"
        private val X_NAMES = setOf("×", "✕", "✖", "x", "✗")
    }

    private class Blob(val l: Int, val t: Int, val r: Int, val b: Int, val strict: Boolean) {
        fun cx() = (l + r) / 2
        fun cy() = (t + b) / 2
        fun contains(x: Int, y: Int) = x in l..r && y in t..b
    }

    private class OcrLine(val norm: String, val cx: Int, val cy: Int)

    private class ZoneDef(val index: Int, val rect: Rect)
    private class ScanResult(val pick: Candidate?, val lines: List<String>)

    private val handler = Handler(Looper.getMainLooper())
    private val worker: ExecutorService = Executors.newSingleThreadExecutor()
    private lateinit var prefs: SharedPreferences

    private var ui: FloatingUi? = null
    private val zoneOverlay by lazy { ZoneOverlay(this) }
    private var cvReady = false
    private var matcher: IconMatcher? = null
    private var loadedVersion = -1
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    @Volatile
    private var busy = false

    @Volatile
    private var pickerActive = false
    private var pausedUntil = 0L
    @Volatile
    private var overlayRect: Rect? = null
    private var scanId = 0
    private var lastClickAt = -100000L
    private var lastClickName = ""
    private var clickCount = 0
    private var lastPkg: String? = null

    // একই জায়গায় বারবার ক্লিক করেও কাজ না হলে ভিন্ন কৌশলে চেষ্টা
    private var lastTx = -1
    private var lastTy = -1
    private var lastTargetAt = -100000L
    private var retry = 0
    private var backoffUntil = 0L

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        onPrefChanged(key)
    }

    private val host = object : UiHost {
        override fun onScanNow() {
            triggerScan(true)
        }

        override fun onSaveShot() {
            saveShot()
        }

        override fun onPickZone(index: Int) {
            startPick(index)
        }

        override fun onClearZone(index: Int) {
            prefs.edit().remove(Prefs.zoneKey(index)).apply()
            refreshZoneInfo()
            ui?.setStatus("জোন $index মুছে ফেলা হয়েছে")
        }

        override fun onShowZones() {
            flashZones(3000)
        }

        override fun onHide() {
            prefs.edit().putBoolean(Prefs.BUBBLE, false).apply()
            postRestoreNotification()
        }

        override fun onToggleApp() {
            toggleCurrentApp()
        }
    }

    private val nodeScan = Runnable {
        try {
            if (prefs.getBoolean(Prefs.ENABLED, true) && !paused()) scanNodeTree()
        } catch (e: Throwable) {
            Log.e(TAG, "node scan", e)
        }
    }

    private val loop = object : Runnable {
        override fun run() {
            try {
                periodic()
            } catch (e: Throwable) {
                Log.e(TAG, "loop", e)
            }
            handler.postDelayed(this, prefs.getInt(Prefs.INTERVAL, Prefs.DEFAULT_INTERVAL).toLong())
        }
    }

    // ---------- জীবনচক্র ----------

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs = Prefs.of(this)
        cvReady = try {
            OpenCVLoader.initLocal()
        } catch (e: Throwable) {
            false
        }
        prefs.registerOnSharedPreferenceChangeListener(prefListener)

        ui?.hide()
        val u = FloatingUi(this, host)
        ui = u
        u.setEnabledState(prefs.getBoolean(Prefs.ENABLED, true))
        if (prefs.getBoolean(Prefs.BUBBLE, true)) u.show()
        refreshZoneInfo()
        refreshAppInfo()
        if (prefs.getBoolean(Prefs.BUBBLE, true)) cancelRestoreNotification()
        if (!cvReady) {
            u.setWarn(true)
            u.setStatus("⚠ OpenCV লোড হয়নি (ছবি মেলানো কাজ করবে না)")
        }

        handler.removeCallbacks(loop)
        handler.postDelayed(loop, 1000)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        ui?.hide()
        try {
            zoneOverlay.clearAll()
        } catch (e: Throwable) {
        }
        if (this::prefs.isInitialized) prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        worker.shutdownNow()
        try {
            recognizer.close()
        } catch (e: Throwable) {
        }
        super.onDestroy()
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!this::prefs.isInitialized) return
        val pkg = event?.packageName?.toString()
        if (pkg == packageName) return
        if (pkg != null && event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            pkg != "com.android.systemui" && !pkg.contains("inputmethod")
        ) {
            lastPkg = pkg
        }
        handler.removeCallbacks(nodeScan)
        handler.postDelayed(nodeScan, EVENT_DEBOUNCE_MS)
    }

    private fun onPrefChanged(key: String?) {
        when (key) {
            Prefs.BUBBLE -> {
                if (prefs.getBoolean(Prefs.BUBBLE, true)) {
                    ui?.show()
                    cancelRestoreNotification()
                } else {
                    ui?.hide()
                }
            }
            Prefs.APPS -> refreshAppInfo()
            Prefs.ENABLED -> ui?.setEnabledState(prefs.getBoolean(Prefs.ENABLED, true))
        }
    }

    // ---------- জোন ----------

    private fun loadZones(): List<ZoneDef> {
        val out = ArrayList<ZoneDef>()
        for (i in 1..3) {
            val s = prefs.getString(Prefs.zoneKey(i), null) ?: continue
            val nums = s.split(',').mapNotNull { it.trim().toIntOrNull() }
            if (nums.size != 4) continue
            out.add(ZoneDef(i, Rect(nums[0], nums[1], nums[2], nums[3])))
        }
        return out
    }

    private fun activeZones(): List<ZoneDef> =
        if (prefs.getBoolean(Prefs.ZONE_MODE, true)) loadZones() else emptyList()

    private fun refreshZoneInfo() {
        for (i in 1..3) ui?.setZoneInfo(i, prefs.contains(Prefs.zoneKey(i)))
    }

    private fun startPick(index: Int) {
        ui?.collapse()
        ui?.setVisible(false)
        pickerActive = true
        zoneOverlay.pick(index) { rect ->
            pickerActive = false
            ui?.setVisible(true)
            if (rect != null) {
                prefs.edit()
                    .putString(Prefs.zoneKey(index), "${rect.left},${rect.top},${rect.right},${rect.bottom}")
                    .apply()
                refreshZoneInfo()
                flashZones(1800)
                ui?.setStatus("জোন $index সেট হয়েছে")
            } else {
                ui?.setStatus("জোন বাছাই বাতিল")
            }
        }
    }

    private fun flashZones(ms: Long) {
        val z = ArrayList<Pair<Int, Rect>>()
        for (d in loadZones()) z.add(Pair(d.index, d.rect))
        if (z.isEmpty()) {
            ui?.setStatus("কোনো জোন সেট করা নেই")
            return
        }
        // দেখানোর সময় স্ক্যান বন্ধ থাকে, যাতে বর্ডার ছবির সঙ্গে মিশে না যায়
        pausedUntil = SystemClock.uptimeMillis() + ms + 400
        zoneOverlay.flash(z, ms)
    }

    // ---------- সময়ে সময়ে স্ক্যান ----------

    private fun screenOn(): Boolean =
        (getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive

    private fun canClickNow(): Boolean =
        SystemClock.uptimeMillis() - lastClickAt >= CLICK_COOLDOWN_MS

    private fun paused(): Boolean = pickerActive || SystemClock.uptimeMillis() < pausedUntil

    private fun periodic() {
        if (!prefs.getBoolean(Prefs.ENABLED, true)) return
        if (!screenOn()) return
        if (paused()) return
        if (scanNodeTree()) return
        triggerScan(false)
    }

    private fun normAlnum(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }

    private fun phrases(key: String, def: String): List<String> {
        val raw = prefs.getString(key, def) ?: ""
        return raw.split(',', '\n').map { normAlnum(it) }.filter { it.length >= 3 }
    }

    // ---------- অ্যাপ ফিল্টার (শুধু স্মার্ট মোডের জন্য) ----------

    private fun appsSet(): Set<String> =
        (prefs.getString(Prefs.APPS, "") ?: "")
            .split(',', '\n', ' ').map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    private fun currentPkg(): String? {
        val p = try {
            rootInActiveWindow?.packageName?.toString()
        } catch (e: Throwable) {
            null
        }
        return if (p != null && p != packageName && p != "com.android.systemui") p else lastPkg
    }

    private fun smartAllowed(): Boolean {
        if (!prefs.getBoolean(Prefs.SMART, true)) return false
        val set = appsSet()
        if (set.isEmpty()) return true
        val p = currentPkg() ?: return false
        return p in set
    }

    private fun toggleCurrentApp() {
        val p = currentPkg()
        if (p == null || p == packageName) {
            ui?.setStatus("অ্যাপ চেনা যায়নি। যে অ্যাপে চালাতে চান সেটা খুলে আবার চাপুন")
            return
        }
        val set = appsSet().toMutableSet()
        val added = if (p in set) {
            set.remove(p)
            false
        } else {
            set.add(p)
            true
        }
        prefs.edit().putString(Prefs.APPS, set.joinToString(",")).apply()
        ui?.setStatus(
            if (added) "স্মার্ট মোড এই অ্যাপে চালু: $p"
            else "এই অ্যাপ বাদ দেওয়া হয়েছে: $p"
        )
    }

    private fun refreshAppInfo() {
        val n = appsSet().size
        ui?.setAppInfo(if (n == 0) "স্মার্ট মোড: সব অ্যাপে" else "স্মার্ট মোড: বাছা $n টি অ্যাপে")
    }

    // ---------- ভাসমান বোতাম লুকালে ফেরানোর নোটিফিকেশন ----------

    private fun postRestoreNotification() {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID, "Auto Close", NotificationManager.IMPORTANCE_LOW)
                )
            }
            val pi = PendingIntent.getBroadcast(
                this, 0, Intent(this, BubbleReceiver::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID)
            else Notification.Builder(this)
            b.setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("Auto Close চলছে")
                .setContentText("ভাসমান বোতাম ফেরাতে এখানে চাপুন")
                .setContentIntent(pi)
                .setOngoing(true)
            nm.notify(BUBBLE_NOTIF_ID, b.build())
        } catch (e: Throwable) {
            Log.e(TAG, "notif", e)
        }
    }

    private fun cancelRestoreNotification() {
        try {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(BUBBLE_NOTIF_ID)
        } catch (e: Throwable) {
        }
    }

    // ---------- বাটনের নাম দেখে ----------

    private fun scanNodeTree(): Boolean {
        if (!canClickNow() || SystemClock.uptimeMillis() < backoffUntil) return false
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() == packageName) return false

        val zones = activeZones()
        val ph = ArrayList<String>()
        ph.addAll(phrases(Prefs.PHRASES, Prefs.DEFAULT_PHRASES))
        if (zones.isNotEmpty()) ph.addAll(phrases(Prefs.PHRASES2, Prefs.DEFAULT_PHRASES2))

        var hit = findNode(root, 0) { n ->
            (zones.isEmpty() || insideZones(n, zones)) &&
                (matches(n.text, ph) || matches(n.contentDescription, ph))
        }
        var label = "নাম দেখে"

        if (hit == null && smartAllowed()) {
            val words = smartWords()
            hit = findNode(root, 0) { n -> smartNodeMatch(n, words) }
            label = "স্মার্ট (নাম)"
        }
        if (hit == null) return false

        // একই নোডে বারবার চেপেও কাজ না হলে কিছুক্ষণ থামি
        val hr = Rect()
        hit.getBoundsInScreen(hr)
        val nowT = SystemClock.uptimeMillis()
        val d = resources.displayMetrics.density
        val same = lastTx >= 0 && abs(hr.centerX() - lastTx) <= 40 * d &&
            abs(hr.centerY() - lastTy) <= 40 * d && nowT - lastTargetAt < 6000
        retry = if (same) retry + 1 else 0
        if (retry >= 6) {
            backoffUntil = nowT + 8000
            retry = 0
            lastTx = -1
            return false
        }
        lastTx = hr.centerX()
        lastTy = hr.centerY()
        lastTargetAt = nowT

        lastClickAt = nowT
        clickCount++
        lastClickName = label
        var n: AccessibilityNodeInfo? = hit
        while (n != null) {
            if (n.isClickable && n.isEnabled && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            n = n.parent
        }
        val r = Rect()
        hit.getBoundsInScreen(r)
        tap(r.centerX(), r.centerY(), 90)
        return true
    }

    private fun smartWords(): List<String> =
        (prefs.getString(Prefs.SMART_WORDS, Prefs.DEFAULT_SMART_WORDS) ?: "")
            .split(',', '\n').map { normAlnum(it) }.filter { it.length >= 2 }

    /** লেখা ছোট (১৪ অক্ষরের মধ্যে) এবং শব্দের সঙ্গে হুবহু মিললে; অথবা আইডিতে close/dismiss/skip থাকলে */
    private fun smartNodeMatch(node: AccessibilityNodeInfo, words: List<String>): Boolean {
        for (cs in arrayOf(node.text, node.contentDescription)) {
            if (cs == null) continue
            val raw = cs.toString().trim().lowercase()
            if (raw.isEmpty() || raw.length > 24) continue
            if (raw in X_NAMES) return true
            if (smartWordHit(normAlnum(raw), words)) return true
        }
        if (node.isClickable) {
            val id = node.viewIdResourceName?.substringAfter('/')?.lowercase()
            if (id != null && (id.contains("close") || id.contains("dismiss") || id.contains("skip")) &&
                !id.contains("closed")
            ) return true
        }
        return false
    }

    private fun smartWordHit(n: String, words: List<String>): Boolean {
        if (n.isEmpty() || n.length > 14) return false
        for (w in words) {
            if (n == w) return true
            if (w.startsWith("skip") && n.startsWith("skip")) return true
            if (w.length >= 5 && n.length >= 4 && lev(n, w) <= 1) return true
        }
        return false
    }

    private fun insideZones(node: AccessibilityNodeInfo, zones: List<ZoneDef>): Boolean {
        val r = Rect()
        node.getBoundsInScreen(r)
        return zones.any { it.rect.contains(r.centerX(), r.centerY()) }
    }

    private fun findNode(
        node: AccessibilityNodeInfo,
        depth: Int,
        pred: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        if (depth > 40) return null
        if (node.isVisibleToUser && pred(node)) return node
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            val f = findNode(c, depth + 1, pred)
            if (f != null) return f
        }
        return null
    }

    private fun matches(cs: CharSequence?, ph: List<String>): Boolean {
        if (cs == null) return false
        val raw = cs.toString().trim()
        if (raw.isEmpty()) return false
        val n = normAlnum(raw)
        if (n.length > 60) return false
        return ph.any { n.contains(it) }
    }

    /** দুই লেখার মধ্যে সম্পাদনা-দূরত্ব (অক্ষর বদল/যোগ/বাদ) */
    private fun lev(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = min(min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost)
            }
            val t = prev
            prev = cur
            cur = t
        }
        return prev[b.length]
    }

    /** OCR ভুল পড়লেও (১-২ অক্ষর) মিলিয়ে নেয় */
    private fun fuzzyContains(n: String, p: String): Boolean {
        if (n.contains(p)) return true
        val tol = if (p.length >= 9) 2 else if (p.length >= 7) 1 else 0
        if (tol == 0) return false
        for (len in (p.length - tol)..(p.length + tol)) {
            if (len > n.length || len < 1) continue
            for (i in 0..(n.length - len)) {
                if (lev(n.substring(i, i + len), p) <= tol) return true
            }
        }
        return false
    }

    // ---------- স্ক্রিনের ছবি নিয়ে ----------

    private fun triggerScan(manual: Boolean) {
        if (busy) return
        if (paused()) return
        if (!manual && !canClickNow()) return
        val allowClick = prefs.getBoolean(Prefs.ENABLED, true)
        val smartOk = smartAllowed()
        busy = true
        overlayRect = ui?.currentRect()

        // কোনো কারণে ছবির কলব্যাক না এলে স্ক্যান যেন চিরতরে আটকে না থাকে
        scanId++
        val myId = scanId
        handler.postDelayed({
            if (busy && scanId == myId) busy = false
        }, 8000)

        try {
            captureFrame { bmp, src ->
                if (bmp == null) {
                    handler.post {
                        ui?.setWarn(true)
                        ui?.setStatus("⚠ স্ক্রিনের ছবি পাওয়া যায়নি\n$src")
                    }
                    busy = false
                    return@captureFrame
                }
                worker.execute { process(bmp, src, allowClick, smartOk) }
            }
        } catch (e: Throwable) {
            Log.e(TAG, "capture start failed", e)
            busy = false
        }
    }

    /** ছবি পেলে onResult ডাকে (যেকোনো থ্রেডে) */
    private fun captureFrame(onResult: (Bitmap?, String) -> Unit) {
        val proj = CaptureBridge.service
        if (proj != null) {
            worker.execute { onResult(proj.grab(), "স্ক্রিন-ক্যাপচার") }
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    var bmp: Bitmap? = null
                    try {
                        val hw = result.hardwareBuffer
                        val hwBmp = Bitmap.wrapHardwareBuffer(hw, result.colorSpace)
                        bmp = hwBmp?.copy(Bitmap.Config.ARGB_8888, true)
                        hwBmp?.recycle()
                        hw.close()
                    } catch (e: Throwable) {
                        Log.e(TAG, "screenshot convert", e)
                    }
                    onResult(bmp, "Accessibility স্ক্রিনশট")
                }

                override fun onFailure(errorCode: Int) {
                    onResult(null, "Accessibility স্ক্রিনশট ব্যর্থ (কোড $errorCode) — বিরতি বাড়িয়ে দেখুন")
                }
            })
            return
        }
        onResult(null, "এই ফোনে (Android 10 বা পুরোনো) অ্যাপ খুলে \"স্ক্রিন-ক্যাপচার চালু করুন\" চাপুন")
    }

    private fun isBlank(bmp: Bitmap): Boolean {
        var bright = 0
        val w = bmp.width
        val h = bmp.height
        for (i in 1..15) {
            for (j in 1..25) {
                val p = bmp.getPixel(w * i / 16, h * j / 26)
                val lum = (Color.red(p) + Color.green(p) + Color.blue(p)) / 3
                if (lum > 12) bright++
            }
        }
        return bright == 0
    }

    // ---------- স্ক্রিনের মাপ ও স্কেল ----------

    @Suppress("DEPRECATION")
    private fun realSize(): Pair<Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            return Pair(b.width(), b.height())
        }
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        return Pair(dm.widthPixels, dm.heightPixels)
    }

    /**
     * স্ক্রিনশটের মাপ আর আসল স্ক্রিনের মাপ আলাদা হলে (কিছু ফোনে হয়) ট্যাপের জায়গা ভুল হয়ে যায়।
     * এই স্কেল দিয়ে স্ক্রিনশটের পিক্সেলকে স্ক্রিনের পিক্সেলে বদলানো হয়। সাধারণত (1.0, 1.0)।
     */
    private fun computeScale(bmp: Bitmap): Pair<Double, Double> {
        val size = realSize()
        val rw = size.first
        val rh = size.second
        if (rw <= 0 || rh <= 0 || bmp.width <= 0 || bmp.height <= 0) return Pair(1.0, 1.0)
        val sx = rw.toDouble() / bmp.width
        val sy = rh.toDouble() / bmp.height
        val sameShape = abs(sx - sy) / sx < 0.02
        val plausible = sx >= 0.5 && sx <= 2.0
        val differs = abs(sx - 1.0) > 0.01
        return if (sameShape && plausible && differs) Pair(sx, sy) else Pair(1.0, 1.0)
    }

    private fun maskOverlay(bmp: Bitmap, sx: Double, sy: Double) {
        val r = overlayRect ?: return
        val scaled = Rect(
            (r.left / sx).toInt(), (r.top / sy).toInt(),
            (r.right / sx).toInt(), (r.bottom / sy).toInt()
        )
        val paint = Paint()
        paint.color = Color.rgb(128, 128, 128)
        Canvas(bmp).drawRect(scaled, paint)
    }

    private fun ensureMatcher(): IconMatcher? {
        if (!cvReady) return null
        val version = prefs.getInt(Prefs.TEMPLATES_VERSION, 0)
        var m = matcher
        if (m == null || version != loadedVersion) {
            matcher?.release()
            m = IconMatcher(TemplateStore.load(this))
            matcher = m
            loadedVersion = version
        }
        return m
    }

    // ---------- প্রধান কাজ ----------

    private fun process(bmp: Bitmap, src: String, allowClick: Boolean, smartOk: Boolean) {
        val t0 = SystemClock.uptimeMillis()
        try {
            val blank = isBlank(bmp)
            val sc = computeScale(bmp)
            maskOverlay(bmp, sc.first, sc.second)

            val m = ensureMatcher()
            val density = resources.displayMetrics.density
            val zones = activeZones()
            var result: ScanResult =
                if (zones.isNotEmpty()) scanZones(bmp, m, zones, sc, density) else scanFull(bmp, m, density)

            if (result.pick == null && smartOk) {
                val s = smartScan(bmp, m, density, sc)
                result = ScanResult(s.pick, result.lines + s.lines)
            } else if (!smartOk && prefs.getBoolean(Prefs.SMART, true)) {
                result = ScanResult(result.pick, result.lines + "স্মার্ট: এই অ্যাপ বাছা তালিকায় নেই")
            }

            // বিটম্যাপের পিক্সেল থেকে স্ক্রিনের পিক্সেলে
            val p = result.pick
            val screenPick: Candidate? =
                if (p == null) null
                else Candidate(p.name, p.group, p.score, (p.x * sc.first).toInt(), (p.y * sc.second).toInt())

            val ms = SystemClock.uptimeMillis() - t0
            val sb = StringBuilder()
            sb.append("ক্যাপচার: ").append(src).append(" (").append(ms).append("ms)\n")
            if (blank) sb.append("⚠ স্ক্রিন কালো আসছে — অ্যাপটি স্ক্রিনশট আটকে রেখেছে\n")
            if (!cvReady) sb.append("⚠ OpenCV লোড হয়নি\n")
            if (sc.first != 1.0) sb.append("স্কেল: ×").append(String.format("%.2f", sc.first)).append('\n')
            for (line in result.lines) sb.append(line).append('\n')
            sb.append(clickLine())
            val text = sb.toString()

            handler.post {
                ui?.setStatus(text)
                ui?.setWarn(blank || !cvReady)
                if (screenPick != null && allowClick) doClick(screenPick)
            }
        } catch (e: Throwable) {
            Log.e(TAG, "process", e)
            handler.post { ui?.setStatus("⚠ ত্রুটি: ${e.javaClass.simpleName}") }
        } finally {
            bmp.recycle()
            busy = false
        }
    }

    private fun threshold(): Double = prefs.getInt(Prefs.THRESHOLD, 70) / 100.0

    /** পুরো স্ক্রিনে খোঁজা (জোন সেট না থাকলে) */
    private fun scanFull(bmp: Bitmap, m: IconMatcher?, density: Float): ScanResult {
        val th = threshold()
        val lines = ArrayList<String>()
        lines.add("মোড: পুরো স্ক্রিন (কোনো জোন সেট নেই)")

        val collect = collectDetect(bmp, bmp.width, phrases(Prefs.PHRASES, Prefs.DEFAULT_PHRASES))
        lines.add("Collect Gem: " + collect.second)

        var iconBest: Candidate? = null
        if (m != null) {
            iconBest = m.scan(bmp, density, setOf("skip", "user"), bmp.width).maxByOrNull { it.score }
            lines.add(fmt("আইকন (>> / আমার)", iconBest?.score, th))
        }

        val pick: Candidate? = collect.first
            ?: if (iconBest != null && iconBest.score >= th) iconBest else null
        return ScanResult(pick, lines)
    }

    /** শুধু বাছা জোনগুলোর ভেতরে খোঁজা। ফেরত আসা পিক্সেল বিটম্যাপের পিক্সেল। */
    private fun scanZones(
        bmp: Bitmap,
        m: IconMatcher?,
        zones: List<ZoneDef>,
        sc: Pair<Double, Double>,
        density: Float
    ): ScanResult {
        // জোন ছোট জায়গা, তাই ভুল মিলের সুযোগ কম; সীমা একটু নামানো হয়েছে
        val th = max(0.45, threshold() - 0.08)
        val groups = setOf("skip", "user")

        val pad = (16 * density).toInt()
        val lines = ArrayList<String>()
        lines.add("মোড: জোন (${zones.size}টা সেট)")
        var pick: Candidate? = null

        for (z in zones) {
            val l = max(0, (z.rect.left / sc.first).toInt() - pad)
            val t = max(0, (z.rect.top / sc.second).toInt() - pad)
            val r = min(bmp.width, (z.rect.right / sc.first).toInt() + pad)
            val b = min(bmp.height, (z.rect.bottom / sc.second).toInt() + pad)
            if (r - l < 32 || b - t < 32) {
                lines.add("জোন ${z.index}: জায়গা স্ক্রিনের বাইরে বা খুব ছোট")
                continue
            }

            val crop = Bitmap.createBitmap(bmp, l, t, r - l, b - t)
            try {
                if (z.index == 1) {
                    val hit = collectDetect(crop, bmp.width, phrases(Prefs.PHRASES, Prefs.DEFAULT_PHRASES))
                    lines.add("জোন ১ (Collect Gem): " + hit.second)
                    val c = hit.first
                    if (c != null && pick == null) {
                        pick = Candidate("Collect Gem", "zone", 1.0, c.x + l, c.y + t)
                    }
                } else {
                    var iconBest: Candidate? = null
                    if (m != null) {
                        iconBest = m.scan(crop, density, groups, bmp.width).maxByOrNull { it.score }
                    }
                    val closeHit = findByOcr(crop, phrases(Prefs.PHRASES2, Prefs.DEFAULT_PHRASES2))
                    val iconOk = iconBest != null && iconBest.score >= th

                    val iconText = if (iconBest == null) "—" else String.format("%.2f", iconBest.score)
                    lines.add(
                        "জোন ${z.index}: আইকন $iconText" + (if (iconOk) " ✅" else "") +
                            ", Close লেখা " + (if (closeHit != null) "পেয়েছি ✅" else "নেই")
                    )

                    if (pick == null) {
                        if (closeHit != null) {
                            pick = Candidate("জোন${z.index} Close", "zone", 1.0, closeHit.x + l, closeHit.y + t)
                        } else if (iconOk && iconBest != null) {
                            pick = Candidate("জোন${z.index} আইকন", "zone", iconBest.score, iconBest.x + l, iconBest.y + t)
                        }
                    }
                }
            } finally {
                crop.recycle()
            }
        }
        return ScanResult(pick, lines)
    }

    // ---------- স্মার্ট মোড: যেকোনো ক্রস / Skip / Close / Next ----------

    private fun smartScan(bmp: Bitmap, m: IconMatcher?, density: Float, sc: Pair<Double, Double>): ScanResult {
        val lines = ArrayList<String>()
        val words = smartWords()
        val ov = overlayRect
        var pick: Candidate? = null

        // ১) লেখা: Close, Skip, Next ...
        val ocr = ocrLines(bmp)
        var textLine: OcrLine? = null
        for (ln in ocr) {
            if (ov != null && ov.contains((ln.cx * sc.first).toInt(), (ln.cy * sc.second).toInt())) continue
            if (smartWordHit(ln.norm, words)) {
                textLine = ln
                break
            }
        }
        if (textLine != null) {
            pick = Candidate("স্মার্ট লেখা: ${textLine.norm}", "smart", 1.0, textLine.cx, textLine.cy)
        }
        lines.add("স্মার্ট লেখা: " + (if (textLine != null) "'${textLine.norm}' ✅" else "নেই"))

        // ২) ক্রস আইকন: শুধু ওপরের ও নিচের পটিতে (মাঝখানে ভুল ধরা এড়াতে)
        if (m != null) {
            val th = max(0.75, threshold())
            val strip = (bmp.height * 0.22).toInt()
            var bestIcon: Candidate? = null
            for (top in booleanArrayOf(true, false)) {
                val y0 = if (top) 0 else bmp.height - strip
                if (strip < 32) continue
                val crop = Bitmap.createBitmap(bmp, 0, y0, bmp.width, strip)
                try {
                    val c = m.scan(crop, density, setOf("builtin"), bmp.width).maxByOrNull { it.score }
                    if (c != null && (bestIcon == null || c.score > bestIcon.score)) {
                        bestIcon = Candidate(c.name, c.group, c.score, c.x, c.y + y0)
                    }
                } finally {
                    crop.recycle()
                }
            }
            val ok = bestIcon != null && bestIcon.score >= th
            lines.add("স্মার্ট ক্রস আইকন: " + (if (bestIcon == null) "—" else String.format("%.2f", bestIcon.score)) + (if (ok) " ✅" else ""))
            if (pick == null && ok && bestIcon != null) {
                pick = Candidate("স্মার্ট আইকন: ${bestIcon.name}", "smart", bestIcon.score, bestIcon.x, bestIcon.y)
            }
        }
        return ScanResult(pick, lines)
    }

    // ---------- Collect Gem বাটন: রং + লেখা ----------

    /**
     * ১) OCR (ভুল বানান সহ্য করে) ২) নীল-সবুজ গ্রেডিয়েন্ট বাটনের আকার/রং।
     * লেখা পাওয়া গেলে এবং বাটন তার ওপর থাকলে বাটনের ঠিক মাঝখানে চাপে।
     * লেখা না পেলেও বাটনের আকার-রং একদম মিললে চাপে।
     * ফেরত: (লক্ষ্য, ব্যাখ্যা)। পিক্সেল img-এর ভেতরের।
     */
    private fun collectDetect(img: Bitmap, refW: Int, ph: List<String>): Pair<Candidate?, String> {
        val ocr = findByOcr(img, ph)
        val blob = findGradientButton(img, refW)
        val desc = (if (ocr != null) "লেখা ✅" else "লেখা নেই") +
            ", রং-বাটন " + (if (blob == null) "নেই" else if (blob.strict) "✅" else "আংশিক")

        if (ocr != null) {
            if (blob != null && blob.contains(ocr.x, ocr.y)) {
                return Pair(Candidate("Collect Gem", "collect", 1.0, blob.cx(), blob.cy()), desc)
            }
            return Pair(Candidate("Collect Gem", "collect", 1.0, ocr.x, ocr.y), desc)
        }
        if (blob != null && blob.strict) {
            return Pair(Candidate("Collect Gem (রং)", "collect", 0.9, blob.cx(), blob.cy()), desc)
        }
        return Pair(null, desc)
    }

    /** নীল-সবুজ রঙের চওড়া, ভেতরে সাদা লেখা-সহ বাটন খোঁজে। ওপেনসিভি লাগে না। */
    private fun findGradientButton(img: Bitmap, refW: Int): Blob? {
        val w = img.width
        val h = img.height
        val step = max(2, w / 180)
        val gw = w / step
        val gh = h / step
        if (gw < 20 || gh < 10) return null

        val mask = BooleanArray(gw * gh)
        val white = BooleanArray(gw * gh)
        val row = IntArray(w)
        val hsv = FloatArray(3)
        for (gy in 0 until gh) {
            img.getPixels(row, 0, w, 0, gy * step, w, 1)
            for (gx in 0 until gw) {
                val p = row[gx * step]
                val r = Color.red(p)
                val g = Color.green(p)
                val b = Color.blue(p)
                if (r > 225 && g > 225 && b > 225) {
                    white[gy * gw + gx] = true
                    continue
                }
                Color.RGBToHSV(r, g, b, hsv)
                if (hsv[0] in 175f..245f && hsv[1] > 0.4f && hsv[2] > 0.55f) mask[gy * gw + gx] = true
            }
        }

        val seen = BooleanArray(gw * gh)
        val stack = IntArray(gw * gh)
        var best: Blob? = null
        var bestScore = 0.0
        for (start in mask.indices) {
            if (!mask[start] || seen[start]) continue
            var sp = 0
            stack[sp++] = start
            seen[start] = true
            var minX = gw
            var maxX = 0
            var minY = gh
            var maxY = 0
            var count = 0
            while (sp > 0) {
                val cur = stack[--sp]
                val cx = cur % gw
                val cy = cur / gw
                count++
                if (cx < minX) minX = cx
                if (cx > maxX) maxX = cx
                if (cy < minY) minY = cy
                if (cy > maxY) maxY = cy
                if (cx > 0 && mask[cur - 1] && !seen[cur - 1]) { seen[cur - 1] = true; stack[sp++] = cur - 1 }
                if (cx < gw - 1 && mask[cur + 1] && !seen[cur + 1]) { seen[cur + 1] = true; stack[sp++] = cur + 1 }
                if (cy > 0 && mask[cur - gw] && !seen[cur - gw]) { seen[cur - gw] = true; stack[sp++] = cur - gw }
                if (cy < gh - 1 && mask[cur + gw] && !seen[cur + gw]) { seen[cur + gw] = true; stack[sp++] = cur + gw }
            }
            val bw = maxX - minX + 1
            val bh = maxY - minY + 1
            if (bh < 3) continue
            val widthFrac = bw.toDouble() * step / refW
            val aspect = bw.toDouble() / bh
            val fill = count.toDouble() / (bw * bh)
            if (widthFrac < 0.30 || widthFrac > 1.02) continue
            if (aspect < 3.0 || aspect > 9.5) continue
            if (fill < 0.55) continue

            var wc = 0
            for (yy in minY..maxY) for (xx in minX..maxX) if (white[yy * gw + xx]) wc++
            val whiteFrac = wc.toDouble() / (bw * bh)
            if (whiteFrac < 0.015 || whiteFrac > 0.30) continue

            val strict = widthFrac >= 0.5 && aspect in 3.8..8.0 && whiteFrac in 0.03..0.20 && fill >= 0.7
            val score = widthFrac * fill + (if (strict) 1.0 else 0.0)
            if (score > bestScore) {
                bestScore = score
                best = Blob(minX * step, minY * step, (maxX + 1) * step, (maxY + 1) * step, strict)
            }
        }
        return best
    }

    // ---------- OCR ----------

    private fun ocrLines(bmp: Bitmap): List<OcrLine> {
        return try {
            val text = Tasks.await(recognizer.process(InputImage.fromBitmap(bmp, 0)), 5, java.util.concurrent.TimeUnit.SECONDS)
            val out = ArrayList<OcrLine>()
            for (block in text.textBlocks) {
                for (line in block.lines) {
                    val box = line.boundingBox ?: continue
                    out.add(OcrLine(normAlnum(line.text), box.centerX(), box.centerY()))
                }
            }
            out
        } catch (e: Exception) {
            Log.e(TAG, "ocr", e)
            emptyList()
        }
    }

    /** স্ক্রিনের লেখা পড়ে নির্ধারিত বাক্য খোঁজে (ভুল বানান সহ্য করে; ফেরত পিক্সেল ওই ছবির ভেতরের) */
    private fun findByOcr(bmp: Bitmap, ph: List<String>): Candidate? {
        if (ph.isEmpty()) return null
        for (ln in ocrLines(bmp)) {
            for (p in ph) {
                if (fuzzyContains(ln.norm, p)) {
                    return Candidate("লেখা: $p", "ocr", 1.0, ln.cx, ln.cy)
                }
            }
        }
        return null
    }

    private fun fmt(label: String, s: Double?, th: Double): String {
        if (s == null) return "$label: —"
        val mark = if (s >= th) " ✅" else ""
        return label + ": " + String.format("%.2f", s) + mark
    }

    private fun best(c: List<Candidate>, group: String): Double? =
        c.filter { it.group == group }.maxOfOrNull { it.score }

    private fun clickLine(): String {
        if (clickCount == 0) return "এখনো ক্লিক হয়নি"
        val sec = (SystemClock.uptimeMillis() - lastClickAt) / 1000
        return "ক্লিক: মোট $clickCount, শেষ $sec সে. আগে ($lastClickName)"
    }

    // ---------- ট্যাপ ----------

    private fun doClick(c: Candidate) {
        val r = overlayRect
        if (r != null && r.contains(c.x, c.y)) return
        val now = SystemClock.uptimeMillis()
        if (now < backoffUntil) return
        if (!canClickNow()) return

        // আগের ক্লিকের একই জায়গায় আবার লক্ষ্য দেখা গেলে ধরে নিই ক্লিক কাজ করেনি: কৌশল বদলাই
        val near = lastTx >= 0 &&
            abs(c.x - lastTx) <= (40 * resources.displayMetrics.density) &&
            abs(c.y - lastTy) <= (40 * resources.displayMetrics.density) &&
            now - lastTargetAt < 6000
        retry = if (near) retry + 1 else 0
        if (retry >= 7) {
            // অনেকবার চেষ্টা করেও কাজ হয়নি; কিছুক্ষণ থেমে আবার শুরু
            backoffUntil = now + 8000
            retry = 0
            lastTx = -1
            return
        }
        lastTx = c.x
        lastTy = c.y
        lastTargetAt = now

        lastClickAt = now
        lastClickName = c.name + (if (retry > 0) " (চেষ্টা ${retry + 1})" else "")
        clickCount++

        val d = resources.displayMetrics.density
        val dx = when (retry % 4) { 2 -> (6 * d).toInt(); 3 -> (-6 * d).toInt(); else -> 0 }
        val dy = when (retry % 4) { 2 -> (3 * d).toInt(); 3 -> (-3 * d).toInt(); else -> 0 }
        if (retry % 2 == 1) clickNodeAt(c.x, c.y)
        tap(c.x + dx, c.y + dy, if (retry == 0) 70 else 140)

        if (prefs.getBoolean(Prefs.DEBUG_TOAST, false)) {
            Toast.makeText(this, "ক্লিক: ${c.name} (${c.x}, ${c.y})", Toast.LENGTH_SHORT).show()
        }
    }

    private fun tap(x: Int, y: Int, durMs: Long) {
        val path = Path()
        path.moveTo(x.toFloat(), y.toFloat())
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durMs))
            .build()
        val ok = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCancelled(gestureDescription: GestureDescription?) {
                clickNodeAt(x, y)
            }
        }, handler)
        if (!ok) clickNodeAt(x, y)
    }

    /** ট্যাপ ব্যর্থ হলে: ওই জায়গার ক্লিকযোগ্য এলিমেন্টে সরাসরি ক্লিক */
    private fun clickNodeAt(x: Int, y: Int) {
        val root = rootInActiveWindow ?: return
        val n = deepestClickableAt(root, x, y, 0) ?: return
        n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun deepestClickableAt(node: AccessibilityNodeInfo, x: Int, y: Int, depth: Int): AccessibilityNodeInfo? {
        if (depth > 40) return null
        val r = Rect()
        node.getBoundsInScreen(r)
        if (!r.contains(x, y)) return null
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            val f = deepestClickableAt(c, x, y, depth + 1)
            if (f != null) return f
        }
        return if (node.isClickable && node.isEnabled) node else null
    }

    // ---------- স্ক্রিনশট সেভ (সমস্যা ধরার জন্য) ----------

    private fun saveShot() {
        if (busy) {
            ui?.setStatus("স্ক্যান চলছে, এক সেকেন্ড পরে আবার চাপুন")
            return
        }
        ui?.setVisible(false)
        handler.postDelayed({
            captureFrame { bmp, src ->
                handler.post { ui?.setVisible(true) }
                if (bmp == null) {
                    handler.post { ui?.setStatus("সেভ ব্যর্থ: $src") }
                    return@captureFrame
                }
                worker.execute {
                    val ok = savePng(bmp)
                    bmp.recycle()
                    handler.post {
                        ui?.setStatus(
                            if (ok) "স্ক্রিনশট সেভ হয়েছে (Pictures/AutoClose)"
                            else "সেভ ব্যর্থ (Android 10+ লাগে)"
                        )
                    }
                }
            }
        }, 500)
    }

    private fun savePng(bmp: Bitmap): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        return try {
            val v = ContentValues()
            v.put(MediaStore.Images.Media.DISPLAY_NAME, "autoclose_" + System.currentTimeMillis() + ".png")
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AutoClose")
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
            if (uri == null) {
                false
            } else {
                contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                true
            }
        } catch (e: Exception) {
            false
        }
    }
}
