package com.junaid.autoclose

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ContentValues
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.util.Log
import android.view.Display
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.opencv.android.OpenCVLoader
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * স্ক্রিন দেখে লক্ষ্য খুঁজে বের করে এবং সেখানে ট্যাপ করে।
 *
 * জোন মোড (ডিফল্ট): ব্যবহারকারী ভাসমান প্যানেল থেকে ২–৩টা জায়গা বেছে দেয়।
 *   জোন ১: "Collect Gem" লেখা খোঁজে
 *   জোন ২, ৩: >> আইকন অথবা "Close" লেখা খোঁজে
 * জোন সেট না থাকলে বা জোন মোড বন্ধ থাকলে পুরো স্ক্রিনে খোঁজে।
 */
class AutoCloseService : AccessibilityService() {

    companion object {
        private const val TAG = "AutoClose"
        private const val CLICK_COOLDOWN_MS = 1500L
        private const val EVENT_DEBOUNCE_MS = 300L
        private val BUILTIN_NAMES = setOf("close", "dismiss", "×", "✕", "✖")
    }

    private class ZoneDef(val index: Int, val rect: Rect)
    private class ScanResult(val pick: Candidate?, val lines: List<String>)

    private val handler = Handler(Looper.getMainLooper())
    private val worker: ExecutorService = Executors.newSingleThreadExecutor()
    private lateinit var prefs: SharedPreferences

    private var ui: FloatingUi? = null
    private val zoneOverlay by lazy { ZoneOverlay(this) }
    private var cvReady = false
    private var matcher: IconMatcher? = null
    private var loadedVersion = -1
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    @Volatile
    private var busy = false

    @Volatile
    private var pickerActive = false
    private var pausedUntil = 0L
    @Volatile
    private var overlayRect: Rect? = null
    private var scanId = 0
    private var lastClickAt = -100000L
    private var lastClickName = ""
    private var clickCount = 0

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        onPrefChanged(key)
    }

    private val host = object : UiHost {
        override fun onScanNow() {
            triggerScan(true)
        }

        override fun onSaveShot() {
            saveShot()
        }

        override fun onPickZone(index: Int) {
            startPick(index)
        }

        override fun onClearZone(index: Int) {
            prefs.edit().remove(Prefs.zoneKey(index)).apply()
            refreshZoneInfo()
            ui?.setStatus("জোন $index মুছে ফেলা হয়েছে")
        }

        override fun onShowZones() {
            flashZones(3000)
        }
    }

    private val nodeScan = Runnable {
        try {
            if (prefs.getBoolean(Prefs.ENABLED, true) && !pickerActive) scanNodeTree()
        } catch (e: Throwable) {
            Log.e(TAG, "node scan", e)
        }
    }

    private val loop = object : Runnable {
        override fun run() {
            try {
                periodic()
            } catch (e: Throwable) {
                Log.e(TAG, "loop", e)
            }
            handler.postDelayed(this, prefs.getInt(Prefs.INTERVAL, 1500).toLong())
        }
    }

    // ---------- জীবনচক্র ----------

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs = Prefs.of(this)
        cvReady = try {
            OpenCVLoader.initLocal()
        } catch (e: Throwable) {
            false
        }
        prefs.registerOnSharedPreferenceChangeListener(prefListener)

        ui?.hide()
        val u = FloatingUi(this, host)
        ui = u
        u.setEnabledState(prefs.getBoolean(Prefs.ENABLED, true))
        if (prefs.getBoolean(Prefs.BUBBLE, true)) u.show()
        refreshZoneInfo()
        if (!cvReady) {
            u.setWarn(true)
            u.setStatus("⚠ OpenCV লোড হয়নি (ছবি মেলানো কাজ করবে না)")
        }

        handler.removeCallbacks(loop)
        handler.postDelayed(loop, 1000)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        ui?.hide()
        try {
            zoneOverlay.clearAll()
        } catch (e: Throwable) {
        }
        if (this::prefs.isInitialized) prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        worker.shutdownNow()
        try {
            recognizer.close()
        } catch (e: Throwable) {
        }
        super.onDestroy()
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!this::prefs.isInitialized) return
        if (event?.packageName?.toString() == packageName) return
        handler.removeCallbacks(nodeScan)
        handler.postDelayed(nodeScan, EVENT_DEBOUNCE_MS)
    }

    private fun onPrefChanged(key: String?) {
        when (key) {
            Prefs.BUBBLE -> {
                if (prefs.getBoolean(Prefs.BUBBLE, true)) ui?.show() else ui?.hide()
            }
            Prefs.ENABLED -> ui?.setEnabledState(prefs.getBoolean(Prefs.ENABLED, true))
        }
    }

    // ---------- জোন ----------

    private fun loadZones(): List<ZoneDef> {
        val out = ArrayList<ZoneDef>()
        for (i in 1..3) {
            val s = prefs.getString(Prefs.zoneKey(i), null) ?: continue
            val nums = s.split(',').mapNotNull { it.trim().toIntOrNull() }
            if (nums.size != 4) continue
            out.add(ZoneDef(i, Rect(nums[0], nums[1], nums[2], nums[3])))
        }
        return out
    }

    private fun activeZones(): List<ZoneDef> =
        if (prefs.getBoolean(Prefs.ZONE_MODE, true)) loadZones() else emptyList()

    private fun refreshZoneInfo() {
        for (i in 1..3) ui?.setZoneInfo(i, prefs.contains(Prefs.zoneKey(i)))
    }

    private fun startPick(index: Int) {
        ui?.collapse()
        ui?.setVisible(false)
        pickerActive = true
        zoneOverlay.pick(index) { rect ->
            pickerActive = false
            ui?.setVisible(true)
            if (rect != null) {
                prefs.edit()
                    .putString(Prefs.zoneKey(index), "${rect.left},${rect.top},${rect.right},${rect.bottom}")
                    .apply()
                refreshZoneInfo()
                flashZones(1800)
                ui?.setStatus("জোন $index সেট হয়েছে")
            } else {
                ui?.setStatus("জোন বাছাই বাতিল")
            }
        }
    }

    private fun flashZones(ms: Long) {
        val z = ArrayList<Pair<Int, Rect>>()
        for (d in loadZones()) z.add(Pair(d.index, d.rect))
        if (z.isEmpty()) {
            ui?.setStatus("কোনো জোন সেট করা নেই")
            return
        }
        // দেখানোর সময় স্ক্যান বন্ধ থাকে, যাতে বর্ডার ছবির সঙ্গে মিশে না যায়
        pausedUntil = SystemClock.uptimeMillis() + ms + 400
        zoneOverlay.flash(z, ms)
    }

    // ---------- সময়ে সময়ে স্ক্যান ----------

    private fun screenOn(): Boolean =
        (getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive

    private fun canClickNow(): Boolean =
        SystemClock.uptimeMillis() - lastClickAt >= CLICK_COOLDOWN_MS

    private fun paused(): Boolean = pickerActive || SystemClock.uptimeMillis() < pausedUntil

    private fun periodic() {
        if (!prefs.getBoolean(Prefs.ENABLED, true)) return
        if (!screenOn()) return
        if (paused()) return
        if (scanNodeTree()) return
        triggerScan(false)
    }

    private fun normAlnum(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }

    private fun phrases(key: String, def: String): List<String> {
        val raw = prefs.getString(key, def) ?: ""
        return raw.split(',', '\n').map { normAlnum(it) }.filter { it.length >= 3 }
    }

    // ---------- বাটনের নাম দেখে ----------

    private fun scanNodeTree(): Boolean {
        val named = prefs.getBoolean(Prefs.G_NODE, true)
        val builtin = prefs.getBoolean(Prefs.G_BUILTIN, false)
        if (!named && !builtin) return false
        if (!canClickNow()) return false
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() == packageName) return false

        val zones = activeZones()
        val ph = ArrayList<String>()
        if (named) {
            ph.addAll(phrases(Prefs.PHRASES, Prefs.DEFAULT_PHRASES))
            if (zones.isNotEmpty()) ph.addAll(phrases(Prefs.PHRASES2, Prefs.DEFAULT_PHRASES2))
        }
        val hit = findNode(root, 0, ph, builtin, zones) ?: return false

        lastClickAt = SystemClock.uptimeMillis()
        clickCount++
        lastClickName = "নাম দেখে"
        var n: AccessibilityNodeInfo? = hit
        while (n != null) {
            if (n.isClickable && n.isEnabled && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            n = n.parent
        }
        val r = Rect()
        hit.getBoundsInScreen(r)
        tap(r.centerX(), r.centerY())
        return true
    }

    private fun insideZones(node: AccessibilityNodeInfo, zones: List<ZoneDef>): Boolean {
        val r = Rect()
        node.getBoundsInScreen(r)
        return zones.any { it.rect.contains(r.centerX(), r.centerY()) }
    }

    private fun findNode(
        node: AccessibilityNodeInfo,
        depth: Int,
        ph: List<String>,
        builtin: Boolean,
        zones: List<ZoneDef>
    ): AccessibilityNodeInfo? {
        if (depth > 40) return null
        if (node.isVisibleToUser) {
            val m = matches(node.text, ph, builtin) || matches(node.contentDescription, ph, builtin)
            if (m && (zones.isEmpty() || insideZones(node, zones))) return node
        }
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            val f = findNode(c, depth + 1, ph, builtin, zones)
            if (f != null) return f
        }
        return null
    }

    private fun matches(cs: CharSequence?, ph: List<String>, builtin: Boolean): Boolean {
        if (cs == null) return false
        val raw = cs.toString().trim().lowercase()
        if (raw.isEmpty()) return false
        if (builtin && raw in BUILTIN_NAMES) return true
        val n = normAlnum(raw)
        if (n.length > 60) return false
        return ph.any { n.contains(it) }
    }

    // ---------- স্ক্রিনের ছবি নিয়ে ----------

    private fun triggerScan(manual: Boolean) {
        if (busy) return
        if (paused()) return
        if (!manual && !canClickNow()) return
        val allowClick = prefs.getBoolean(Prefs.ENABLED, true)
        busy = true
        overlayRect = ui?.currentRect()

        // কোনো কারণে ছবির কলব্যাক না এলে স্ক্যান যেন চিরতরে আটকে না থাকে
        scanId++
        val myId = scanId
        handler.postDelayed({
            if (busy && scanId == myId) busy = false
        }, 8000)

        try {
            captureFrame { bmp, src ->
                if (bmp == null) {
                    handler.post {
                        ui?.setWarn(true)
                        ui?.setStatus("⚠ স্ক্রিনের ছবি পাওয়া যায়নি\n$src")
                    }
                    busy = false
                    return@captureFrame
                }
                worker.execute { process(bmp, src, allowClick) }
            }
        } catch (e: Throwable) {
            Log.e(TAG, "capture start failed", e)
            busy = false
        }
    }

    /** ছবি পেলে onResult ডাকে (যেকোনো থ্রেডে) */
    private fun captureFrame(onResult: (Bitmap?, String) -> Unit) {
        val proj = CaptureBridge.service
        if (proj != null) {
            worker.execute { onResult(proj.grab(), "স্ক্রিন-ক্যাপচার") }
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    var bmp: Bitmap? = null
                    try {
                        val hw = result.hardwareBuffer
                        val hwBmp = Bitmap.wrapHardwareBuffer(hw, result.colorSpace)
                        bmp = hwBmp?.copy(Bitmap.Config.ARGB_8888, true)
                        hwBmp?.recycle()
                        hw.close()
                    } catch (e: Throwable) {
                        Log.e(TAG, "screenshot convert", e)
                    }
                    onResult(bmp, "Accessibility স্ক্রিনশট")
                }

                override fun onFailure(errorCode: Int) {
                    onResult(null, "Accessibility স্ক্রিনশট ব্যর্থ (কোড $errorCode)")
                }
            })
            return
        }
        onResult(null, "এই ফোনে (Android 10 বা পুরোনো) অ্যাপ খুলে \"স্ক্রিন-ক্যাপচার চালু করুন\" চাপুন")
    }

    private fun isBlank(bmp: Bitmap): Boolean {
        var bright = 0
        val w = bmp.width
        val h = bmp.height
        for (i in 1..15) {
            for (j in 1..25) {
                val p = bmp.getPixel(w * i / 16, h * j / 26)
                val lum = (Color.red(p) + Color.green(p) + Color.blue(p)) / 3
                if (lum > 12) bright++
            }
        }
        return bright == 0
    }

    // ---------- স্ক্রিনের মাপ ও স্কেল ----------

    @Suppress("DEPRECATION")
    private fun realSize(): Pair<Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            return Pair(b.width(), b.height())
        }
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        return Pair(dm.widthPixels, dm.heightPixels)
    }

    /**
     * স্ক্রিনশটের মাপ আর আসল স্ক্রিনের মাপ আলাদা হলে (কিছু ফোনে হয়) ট্যাপের জায়গা ভুল হয়ে যায়।
     * এই স্কেল দিয়ে স্ক্রিনশটের পিক্সেলকে স্ক্রিনের পিক্সেলে বদলানো হয়। সাধারণত (1.0, 1.0)।
     */
    private fun computeScale(bmp: Bitmap): Pair<Double, Double> {
        val size = realSize()
        val rw = size.first
        val rh = size.second
        if (rw <= 0 || rh <= 0 || bmp.width <= 0 || bmp.height <= 0) return Pair(1.0, 1.0)
        val sx = rw.toDouble() / bmp.width
        val sy = rh.toDouble() / bmp.height
        val sameShape = abs(sx - sy) / sx < 0.02
        val plausible = sx >= 0.5 && sx <= 2.0
        val differs = abs(sx - 1.0) > 0.01
        return if (sameShape && plausible && differs) Pair(sx, sy) else Pair(1.0, 1.0)
    }

    private fun maskOverlay(bmp: Bitmap, sx: Double, sy: Double) {
        val r = overlayRect ?: return
        val scaled = Rect(
            (r.left / sx).toInt(), (r.top / sy).toInt(),
            (r.right / sx).toInt(), (r.bottom / sy).toInt()
        )
        val paint = Paint()
        paint.color = Color.rgb(128, 128, 128)
        Canvas(bmp).drawRect(scaled, paint)
    }

    private fun ensureMatcher(): IconMatcher? {
        if (!cvReady) return null
        val version = prefs.getInt(Prefs.TEMPLATES_VERSION, 0)
        var m = matcher
        if (m == null || version != loadedVersion) {
            matcher?.release()
            m = IconMatcher(TemplateStore.load(this))
            matcher = m
            loadedVersion = version
        }
        return m
    }

    // ---------- প্রধান কাজ ----------

    private fun process(bmp: Bitmap, src: String, allowClick: Boolean) {
        val t0 = SystemClock.uptimeMillis()
        try {
            val blank = isBlank(bmp)
            val sc = computeScale(bmp)
            maskOverlay(bmp, sc.first, sc.second)

            val m = ensureMatcher()
            val density = resources.displayMetrics.density
            val zones = activeZones()
            val result: ScanResult =
                if (zones.isNotEmpty()) scanZones(bmp, m, zones, sc, density) else scanFull(bmp, m, density)

            // বিটম্যাপের পিক্সেল থেকে স্ক্রিনের পিক্সেলে
            val p = result.pick
            val screenPick: Candidate? =
                if (p == null) null
                else Candidate(p.name, p.group, p.score, (p.x * sc.first).toInt(), (p.y * sc.second).toInt())

            val ms = SystemClock.uptimeMillis() - t0
            val sb = StringBuilder()
            sb.append("ক্যাপচার: ").append(src).append(" (").append(ms).append("ms)\n")
            if (blank) sb.append("⚠ স্ক্রিন কালো আসছে — অ্যাপটি স্ক্রিনশট আটকে রেখেছে\n")
            if (!cvReady) sb.append("⚠ OpenCV লোড হয়নি\n")
            if (sc.first != 1.0) sb.append("স্কেল: ×").append(String.format("%.2f", sc.first)).append('\n')
            for (line in result.lines) sb.append(line).append('\n')
            sb.append(clickLine())
            val text = sb.toString()

            handler.post {
                ui?.setStatus(text)
                ui?.setWarn(blank || !cvReady)
                if (screenPick != null && allowClick) doClick(screenPick)
            }
        } catch (e: Throwable) {
            Log.e(TAG, "process", e)
            handler.post { ui?.setStatus("⚠ ত্রুটি: ${e.javaClass.simpleName}") }
        } finally {
            bmp.recycle()
            busy = false
        }
    }

    /** পুরো স্ক্রিনে খোঁজা (জোন সেট না থাকলে) */
    private fun scanFull(bmp: Bitmap, m: IconMatcher?, density: Float): ScanResult {
        val threshold = prefs.getInt(Prefs.THRESHOLD, 70) / 100.0

        val groups = HashSet<String>()
        if (prefs.getBoolean(Prefs.G_SKIP, true)) groups.add("skip")
        if (prefs.getBoolean(Prefs.G_BUTTON, true)) groups.add("button")
        if (prefs.getBoolean(Prefs.G_BUILTIN, false)) groups.add("builtin")
        if (prefs.getBoolean(Prefs.G_USER, true)) groups.add("user")

        val cands: List<Candidate> = if (m != null) m.scan(bmp, density, groups) else emptyList()

        var ocr: Candidate? = null
        val useOcr = prefs.getBoolean(Prefs.G_OCR, true)
        if (useOcr) ocr = findByOcr(bmp, phrases(Prefs.PHRASES, Prefs.DEFAULT_PHRASES))

        val hits = cands.filter { it.score >= threshold }
        val pick: Candidate? = ocr ?: hits.maxByOrNull { it.score }

        val lines = ArrayList<String>()
        lines.add("মোড: পুরো স্ক্রিন (কোনো জোন সেট নেই বা জোন মোড বন্ধ)")
        if ("skip" in groups) lines.add(fmt("আইকন >>", best(cands, "skip"), threshold))
        if ("button" in groups) lines.add(fmt("বাটন (ছবি)", best(cands, "button"), threshold))
        if ("builtin" in groups) lines.add(fmt("বিল্ট-ইন", best(cands, "builtin"), threshold))
        if ("user" in groups) lines.add(fmt("আমার আইকন", best(cands, "user"), threshold))
        if (useOcr) lines.add("বাটন (লেখা): " + (if (ocr != null) "পেয়েছি ✅" else "নেই"))
        return ScanResult(pick, lines)
    }

    /** শুধু বাছা জোনগুলোর ভেতরে খোঁজা। ফেরত আসা পিক্সেল বিটম্যাপের পিক্সেল। */
    private fun scanZones(
        bmp: Bitmap,
        m: IconMatcher?,
        zones: List<ZoneDef>,
        sc: Pair<Double, Double>,
        density: Float
    ): ScanResult {
        // জোন ছোট জায়গা, তাই ভুল মিলের সুযোগ কম; সীমা একটু নামানো হয়েছে
        val th = max(0.45, prefs.getInt(Prefs.THRESHOLD, 70) / 100.0 - 0.08)

        val groups = HashSet<String>()
        if (prefs.getBoolean(Prefs.G_SKIP, true)) groups.add("skip")
        if (prefs.getBoolean(Prefs.G_USER, true)) groups.add("user")
        if (prefs.getBoolean(Prefs.G_BUILTIN, false)) groups.add("builtin")

        val pad = (16 * density).toInt()
        val lines = ArrayList<String>()
        lines.add("মোড: জোন (${zones.size}টা সেট)")
        var pick: Candidate? = null

        for (z in zones) {
            val l = max(0, (z.rect.left / sc.first).toInt() - pad)
            val t = max(0, (z.rect.top / sc.second).toInt() - pad)
            val r = min(bmp.width, (z.rect.right / sc.first).toInt() + pad)
            val b = min(bmp.height, (z.rect.bottom / sc.second).toInt() + pad)
            if (r - l < 32 || b - t < 32) {
                lines.add("জোন ${z.index}: জায়গা স্ক্রিনের বাইরে বা খুব ছোট")
                continue
            }

            val crop = Bitmap.createBitmap(bmp, l, t, r - l, b - t)
            try {
                if (z.index == 1) {
                    val hit = findByOcr(crop, phrases(Prefs.PHRASES, Prefs.DEFAULT_PHRASES))
                    lines.add("জোন ১ (Collect Gem): " + (if (hit != null) "লেখা পেয়েছি ✅" else "নেই"))
                    if (hit != null && pick == null) {
                        pick = Candidate("জোন১ লেখা", "zone", 1.0, hit.x + l, hit.y + t)
                    }
                } else {
                    var iconBest: Candidate? = null
                    if (m != null) {
                        iconBest = m.scan(crop, density, groups, bmp.width).maxByOrNull { it.score }
                    }
                    val closeHit = findByOcr(crop, phrases(Prefs.PHRASES2, Prefs.DEFAULT_PHRASES2))
                    val iconOk = iconBest != null && iconBest.score >= th

                    val iconText = if (iconBest == null) "—" else String.format("%.2f", iconBest.score)
                    lines.add(
                        "জোন ${z.index}: আইকন $iconText" + (if (iconOk) " ✅" else "") +
                            ", Close লেখা " + (if (closeHit != null) "পেয়েছি ✅" else "নেই")
                    )

                    if (pick == null) {
                        if (closeHit != null) {
                            pick = Candidate("জোন${z.index} Close", "zone", 1.0, closeHit.x + l, closeHit.y + t)
                        } else if (iconOk && iconBest != null) {
                            pick = Candidate("জোন${z.index} আইকন", "zone", iconBest.score, iconBest.x + l, iconBest.y + t)
                        }
                    }
                }
            } finally {
                crop.recycle()
            }
        }
        return ScanResult(pick, lines)
    }

    /** স্ক্রিনের লেখা পড়ে নির্ধারিত বাক্য খোঁজে (ফেরত পিক্সেল ওই ছবির ভেতরের) */
    private fun findByOcr(bmp: Bitmap, ph: List<String>): Candidate? {
        if (ph.isEmpty()) return null
        return try {
            val text = Tasks.await(recognizer.process(InputImage.fromBitmap(bmp, 0)))
            var found: Candidate? = null
            for (block in text.textBlocks) {
                for (line in block.lines) {
                    val n = normAlnum(line.text)
                    val box = line.boundingBox
                    if (box == null || found != null) continue
                    for (p in ph) {
                        if (n.contains(p)) {
                            found = Candidate("লেখা: $p", "ocr", 1.0, box.centerX(), box.centerY())
                            break
                        }
                    }
                }
            }
            found
        } catch (e: Exception) {
            Log.e(TAG, "ocr", e)
            null
        }
    }

    private fun fmt(label: String, s: Double?, th: Double): String {
        if (s == null) return "$label: —"
        val mark = if (s >= th) " ✅" else ""
        return label + ": " + String.format("%.2f", s) + mark
    }

    private fun best(c: List<Candidate>, group: String): Double? =
        c.filter { it.group == group }.maxOfOrNull { it.score }

    private fun clickLine(): String {
        if (clickCount == 0) return "এখনো ক্লিক হয়নি"
        val sec = (SystemClock.uptimeMillis() - lastClickAt) / 1000
        return "ক্লিক: মোট $clickCount, শেষ $sec সে. আগে ($lastClickName)"
    }

    // ---------- ট্যাপ ----------

    private fun doClick(c: Candidate) {
        val r = overlayRect
        if (r != null && r.contains(c.x, c.y)) return
        if (!canClickNow()) return
        lastClickAt = SystemClock.uptimeMillis()
        lastClickName = c.name
        clickCount++
        tap(c.x, c.y)
        if (prefs.getBoolean(Prefs.DEBUG_TOAST, false)) {
            Toast.makeText(this, "ক্লিক: ${c.name} (${c.x}, ${c.y})", Toast.LENGTH_SHORT).show()
        }
    }

    private fun tap(x: Int, y: Int) {
        val path = Path()
        path.moveTo(x.toFloat(), y.toFloat())
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 90))
            .build()
        val ok = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCancelled(gestureDescription: GestureDescription?) {
                clickNodeAt(x, y)
            }
        }, handler)
        if (!ok) clickNodeAt(x, y)
    }

    /** ট্যাপ ব্যর্থ হলে: ওই জায়গার ক্লিকযোগ্য এলিমেন্টে সরাসরি ক্লিক */
    private fun clickNodeAt(x: Int, y: Int) {
        val root = rootInActiveWindow ?: return
        val n = deepestClickableAt(root, x, y, 0) ?: return
        n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun deepestClickableAt(node: AccessibilityNodeInfo, x: Int, y: Int, depth: Int): AccessibilityNodeInfo? {
        if (depth > 40) return null
        val r = Rect()
        node.getBoundsInScreen(r)
        if (!r.contains(x, y)) return null
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            val f = deepestClickableAt(c, x, y, depth + 1)
            if (f != null) return f
        }
        return if (node.isClickable && node.isEnabled) node else null
    }

    // ---------- স্ক্রিনশট সেভ (সমস্যা ধরার জন্য) ----------

    private fun saveShot() {
        if (busy) {
            ui?.setStatus("স্ক্যান চলছে, এক সেকেন্ড পরে আবার চাপুন")
            return
        }
        ui?.setVisible(false)
        handler.postDelayed({
            captureFrame { bmp, src ->
                handler.post { ui?.setVisible(true) }
                if (bmp == null) {
                    handler.post { ui?.setStatus("সেভ ব্যর্থ: $src") }
                    return@captureFrame
                }
                worker.execute {
                    val ok = savePng(bmp)
                    bmp.recycle()
                    handler.post {
                        ui?.setStatus(
                            if (ok) "স্ক্রিনশট সেভ হয়েছে (Pictures/AutoClose)"
                            else "সেভ ব্যর্থ (Android 10+ লাগে)"
                        )
                    }
                }
            }
        }, 500)
    }

    private fun savePng(bmp: Bitmap): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        return try {
            val v = ContentValues()
            v.put(MediaStore.Images.Media.DISPLAY_NAME, "autoclose_" + System.currentTimeMillis() + ".png")
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AutoClose")
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
            if (uri == null) {
                false
            } else {
                contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                true
            }
        } catch (e: Exception) {
            false
        }
    }
}
