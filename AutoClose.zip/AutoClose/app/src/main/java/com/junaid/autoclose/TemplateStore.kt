package com.junaid.autoclose

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import org.opencv.android.Utils
import org.opencv.core.Mat
import org.opencv.imgproc.Imgproc
import java.io.File

object TemplateStore {

    private const val ASSET_DIR = "templates"

    fun dir(ctx: Context): File = File(ctx.filesDir, "templates").apply { mkdirs() }

    fun userCount(ctx: Context): Int = dir(ctx).listFiles()?.size ?: 0

    fun bundledCount(ctx: Context): Int = ctx.assets.list(ASSET_DIR)?.size ?: 0

    fun clearUser(ctx: Context) {
        dir(ctx).listFiles()?.forEach { it.delete() }
    }

    /** OpenCV চালু হওয়ার পরে ডাকতে হবে */
    fun load(ctx: Context): List<IconTemplate> {
        val out = ArrayList<IconTemplate>()

        // ১) কোডে আঁকা আইকন
        for ((name, bmp) in BuiltinIcons.all()) {
            out.add(toTemplate(name, bmp, Kind.BUILTIN, "builtin"))
        }

        // ২) অ্যাপের সঙ্গে দেওয়া ছবি (app/src/main/assets/templates)
        //    icon_... = ছোট আইকন (Collect Gem বাটন এখন রং + লেখা দিয়ে ধরা হয়)
        val files = ctx.assets.list(ASSET_DIR)
        if (files != null) {
            for (file in files.sorted()) {
                val bmp = ctx.assets.open("$ASSET_DIR/$file").use { BitmapFactory.decodeStream(it) }
                    ?: continue
                // আইকন (>> ইত্যাদি): পর্দার প্রস্থের ছোট শতাংশ ধরে খোঁজা হয়
                out.add(toTemplate(file, bmp, Kind.RANGE, "skip", 0.03, 0.14, 12))
            }
        }

        // ৩) অ্যাপ থেকে ইউজারের যোগ করা ছবি
        val users = dir(ctx).listFiles()
        if (users != null) {
            for (f in users.sortedBy { it.name }) {
                val bmp = BitmapFactory.decodeFile(f.path) ?: continue
                out.add(toTemplate(f.name, bmp, Kind.NATIVE, "user"))
            }
        }
        return out
    }

    private fun toTemplate(
        name: String,
        src: Bitmap,
        kind: Kind,
        group: String,
        minFrac: Double = 0.0,
        maxFrac: Double = 0.0,
        steps: Int = 8
    ): IconTemplate {
        // স্বচ্ছ অংশ সাদা করে নেওয়া হয়
        val flat = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(flat)
        c.drawColor(Color.WHITE)
        c.drawBitmap(src, 0f, 0f, null)

        val rgba = Mat()
        Utils.bitmapToMat(flat, rgba)
        val gray = Mat()
        Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
        rgba.release()
        return IconTemplate(name, gray, kind, group, minFrac, maxFrac, steps)
    }
}
