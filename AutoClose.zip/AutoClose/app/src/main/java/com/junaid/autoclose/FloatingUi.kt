package com.junaid.autoclose

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

interface UiHost {
    fun onScanNow()
    fun onSaveShot()
    fun onPickZone(index: Int)
    fun onClearZone(index: Int)
    fun onShowZones()
}

/**
 * স্ক্রিনের উপরে ভাসমান "AC" বোতাম। চাপলে ছোট কন্ট্রোল প্যানেল খোলে।
 * Accessibility overlay হিসেবে আঁকা হয়, তাই আলাদা "Display over other apps" অনুমতি লাগে না।
 */
class FloatingUi(private val ctx: Context, private val host: UiHost) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val prefs: SharedPreferences = Prefs.of(ctx)
    private val density: Float = ctx.resources.displayMetrics.density

    private lateinit var root: LinearLayout
    private lateinit var bubble: TextView
    private lateinit var scroll: ScrollView
    private lateinit var statusView: TextView
    private lateinit var enabledSwitch: Switch
    private lateinit var params: WindowManager.LayoutParams
    private val zoneLabels = arrayOfNulls<TextView>(4)

    private var attached = false
    private var expanded = false
    private var suppress = false
    private var warn = false

    private fun dp(v: Int): Int = (v * density).toInt()

    init {
        build()
    }

    // ---------- বাইরের জন্য ----------

    fun show() {
        if (attached) return
        try {
            wm.addView(root, params)
            attached = true
        } catch (e: Exception) {
            attached = false
        }
    }

    fun hide() {
        if (!attached) return
        try {
            wm.removeView(root)
        } catch (e: Exception) {
            // কিছু করার নেই
        }
        attached = false
    }

    fun setVisible(v: Boolean) {
        root.visibility = if (v) View.VISIBLE else View.INVISIBLE
    }

    fun setStatus(t: String) {
        statusView.text = t
    }

    fun setWarn(w: Boolean) {
        warn = w
        refreshBubble()
    }

    fun setEnabledState(on: Boolean) {
        suppress = true
        enabledSwitch.isChecked = on
        suppress = false
        refreshBubble()
    }

    fun setZoneInfo(index: Int, isSet: Boolean) {
        if (index in 1..3) zoneLabels[index]?.text = zoneTitle(index, isSet)
    }

    /** প্যানেল বন্ধ করে শুধু বোতাম রাখে */
    fun collapse() {
        if (!expanded) return
        expanded = false
        scroll.visibility = View.GONE
        if (attached) wm.updateViewLayout(root, params)
    }

    /** স্ক্রিনে এই ভাসমান অংশ কোথায় আছে (স্ক্রিনশট থেকে এই জায়গা বাদ দিতে) */
    fun currentRect(): Rect? {
        if (!attached) return null
        val loc = IntArray(2)
        root.getLocationOnScreen(loc)
        return Rect(loc[0], loc[1], loc[0] + root.width, loc[1] + root.height)
    }

    // ---------- তৈরি ----------

    private fun enabledNow(): Boolean = prefs.getBoolean(Prefs.ENABLED, true)

    private fun zoneTitle(i: Int, isSet: Boolean): String {
        val what = if (i == 1) "Collect Gem" else "আইকন / Close"
        return "জোন $i ($what): " + (if (isSet) "সেট ✓" else "নেই")
    }

    private fun refreshBubble() {
        val color = when {
            !enabledNow() -> "#757575"
            warn -> "#EF6C00"
            else -> "#2E7D32"
        }
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(Color.parseColor(color))
        bubble.background = bg
        bubble.alpha = 0.92f
    }

    private fun label(text: String, sizeSp: Float, topDp: Int): TextView {
        val tv = TextView(ctx)
        tv.text = text
        tv.textSize = sizeSp
        tv.setTextColor(Color.BLACK)
        tv.setPadding(0, dp(topDp), 0, 0)
        return tv
    }

    private fun build() {
        val dm = ctx.resources.displayMetrics

        bubble = TextView(ctx)
        bubble.text = "AC"
        bubble.setTextColor(Color.WHITE)
        bubble.textSize = 14f
        bubble.typeface = Typeface.DEFAULT_BOLD
        bubble.gravity = Gravity.CENTER
        bubble.layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))

        val panel = LinearLayout(ctx)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(12), dp(10), dp(12), dp(10))
        val panelBg = GradientDrawable()
        panelBg.setColor(Color.parseColor("#F7FFFFFF"))
        panelBg.cornerRadius = dp(14).toFloat()
        panelBg.setStroke(dp(1), Color.parseColor("#33000000"))
        panel.background = panelBg

        val title = label("Auto Close", 15f, 0)
        title.typeface = Typeface.DEFAULT_BOLD
        panel.addView(title)

        enabledSwitch = Switch(ctx)
        enabledSwitch.text = "অটো-ক্লিক চালু"
        enabledSwitch.setTextColor(Color.BLACK)
        enabledSwitch.isChecked = enabledNow()
        enabledSwitch.setOnCheckedChangeListener { _, checked ->
            if (!suppress) {
                prefs.edit().putBoolean(Prefs.ENABLED, checked).apply()
                refreshBubble()
            }
        }
        panel.addView(enabledSwitch)

        statusView = label("এখনো স্ক্যান হয়নি", 11f, 6)
        statusView.setTextColor(Color.parseColor("#222222"))
        statusView.setPadding(0, dp(6), 0, dp(6))
        panel.addView(statusView)

        addSeek(panel, "সংবেদনশীলতা (মিলের সীমা)", 40, 95, 1, Prefs.THRESHOLD, 70) { "$it%" }
        addSeek(panel, "স্ক্যানের বিরতি", 500, 5000, 100, Prefs.INTERVAL, 1500) {
            String.format("%.1f সে.", it / 1000.0)
        }

        // ---- জোন ----
        val zoneHead = label("জায়গা বেছে নিন (জোন):", 12f, 8)
        zoneHead.typeface = Typeface.DEFAULT_BOLD
        panel.addView(zoneHead)
        panel.addView(label("জোন ১-এ Collect Gem লেখা, জোন ২-৩-এ >> আইকন বা Close লেখা খুঁজবে।", 10f, 0))
        addCheck(panel, "জোন মোড (শুধু বাছা জায়গায় খোঁজো)", Prefs.ZONE_MODE, true)
        for (i in 1..3) addZoneRow(panel, i)
        val showBtn = Button(ctx)
        showBtn.text = "জোনগুলো দেখাও (৩ সে.)"
        showBtn.textSize = 12f
        showBtn.setOnClickListener { host.onShowZones() }
        panel.addView(showBtn)

        // ---- কী খুঁজবে ----
        panel.addView(label("কী খুঁজবে:", 12f, 8))
        addCheck(panel, "ছোট আইকন (>>)", Prefs.G_SKIP, true)
        addCheck(panel, "বাটন (ছবি মিলিয়ে)", Prefs.G_BUTTON, true)
        addCheck(panel, "বাটন (লেখা পড়ে)", Prefs.G_OCR, true)
        addCheck(panel, "বাটনের নাম দেখে", Prefs.G_NODE, true)
        addCheck(panel, "বিল্ট-ইন × / >> / Close", Prefs.G_BUILTIN, false)
        addCheck(panel, "আমার যোগ করা আইকন", Prefs.G_USER, true)

        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        val scanBtn = Button(ctx)
        scanBtn.text = "এখনই স্ক্যান"
        scanBtn.textSize = 12f
        scanBtn.setOnClickListener { host.onScanNow() }
        val shotBtn = Button(ctx)
        shotBtn.text = "স্ক্রিনশট সেভ"
        shotBtn.textSize = 12f
        shotBtn.setOnClickListener { host.onSaveShot() }
        row.addView(scanBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(shotBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        panel.addView(row)

        val hint = label("AC বোতাম টেনে সরানো যায়, চাপলে প্যানেল বন্ধ হয়।", 10f, 4)
        hint.setTextColor(Color.parseColor("#555555"))
        panel.addView(hint)

        scroll = ScrollView(ctx)
        scroll.addView(panel)
        val maxH = min(dp(440), dm.heightPixels - dp(140))
        scroll.layoutParams = LinearLayout.LayoutParams(dp(290), maxH)
        scroll.visibility = View.GONE

        root = LinearLayout(ctx)
        root.orientation = LinearLayout.VERTICAL
        root.addView(bubble)
        root.addView(scroll)

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = prefs.getInt(Prefs.BUBBLE_X, dp(8))
        params.y = prefs.getInt(Prefs.BUBBLE_Y, dp(220))

        refreshBubble()
        installDrag()
    }

    private fun addZoneRow(parent: LinearLayout, i: Int) {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL

        val tv = TextView(ctx)
        tv.textSize = 12f
        tv.setTextColor(Color.BLACK)
        tv.text = zoneTitle(i, prefs.contains(Prefs.zoneKey(i)))
        zoneLabels[i] = tv

        val pick = Button(ctx)
        pick.text = "বাছুন"
        pick.textSize = 11f
        pick.minWidth = 0
        pick.minimumWidth = 0
        pick.setPadding(dp(8), 0, dp(8), 0)
        pick.setOnClickListener {
            collapse()
            host.onPickZone(i)
        }

        val clear = Button(ctx)
        clear.text = "মুছুন"
        clear.textSize = 11f
        clear.minWidth = 0
        clear.minimumWidth = 0
        clear.setPadding(dp(8), 0, dp(8), 0)
        clear.setOnClickListener { host.onClearZone(i) }

        row.addView(tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(pick)
        row.addView(clear)
        parent.addView(row)
    }

    private fun installDrag() {
        bubble.setOnTouchListener(object : View.OnTouchListener {
            private var startRawX = 0f
            private var startRawY = 0f
            private var startX = 0
            private var startY = 0
            private var moved = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startRawX = e.rawX
                        startRawY = e.rawY
                        startX = params.x
                        startY = params.y
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - startRawX).toInt()
                        val dy = (e.rawY - startRawY).toInt()
                        if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                        if (moved) {
                            params.x = startX + dx
                            params.y = startY + dy
                            if (attached) wm.updateViewLayout(root, params)
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (moved) {
                            prefs.edit()
                                .putInt(Prefs.BUBBLE_X, params.x)
                                .putInt(Prefs.BUBBLE_Y, params.y)
                                .apply()
                        } else {
                            toggle()
                        }
                        return true
                    }
                }
                return false
            }
        })
    }

    private fun toggle() {
        expanded = !expanded
        scroll.visibility = if (expanded) View.VISIBLE else View.GONE
        if (expanded) {
            val dm = ctx.resources.displayMetrics
            val panelH = scroll.layoutParams.height
            params.x = params.x.coerceIn(0, max(0, dm.widthPixels - dp(290)))
            params.y = params.y.coerceIn(0, max(0, dm.heightPixels - dp(48) - panelH))
        }
        if (attached) wm.updateViewLayout(root, params)
    }

    private fun addCheck(parent: LinearLayout, label: String, key: String, def: Boolean) {
        val cb = CheckBox(ctx)
        cb.text = label
        cb.textSize = 13f
        cb.setTextColor(Color.BLACK)
        cb.isChecked = prefs.getBoolean(key, def)
        cb.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(key, checked).apply()
        }
        parent.addView(cb)
    }

    private fun addSeek(
        parent: LinearLayout,
        title: String,
        minV: Int,
        maxV: Int,
        step: Int,
        key: String,
        def: Int,
        fmt: (Int) -> String
    ) {
        val cur = prefs.getInt(key, def)
        val tv = label("$title: ${fmt(cur)}", 12f, 6)

        val sb = SeekBar(ctx)
        sb.max = (maxV - minV) / step
        sb.progress = (cur - minV) / step
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = minV + p * step
                tv.text = "$title: ${fmt(v)}"
                if (fromUser) prefs.edit().putInt(key, v).apply()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(tv)
        parent.addView(sb)
    }
}
