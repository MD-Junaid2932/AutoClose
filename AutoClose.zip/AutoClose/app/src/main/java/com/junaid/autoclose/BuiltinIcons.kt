package com.junaid.autoclose

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF

/**
 * বিজ্ঞাপনে সাধারণত যেসব ক্রস (×) আইকন দেখা যায় তার কয়েকটা ধরন কোড দিয়ে আঁকা হয়।
 * মেলানো হয় আউটলাইন ধরে, তাই আইকন কালো না সাদা তাতে সমস্যা হয় না।
 * (>> বা Skip আইকন আলাদা ছবি হিসেবে assets/templates-এ আছে।)
 */
object BuiltinIcons {

    private const val S = 96

    fun all(): List<Pair<String, Bitmap>> = listOf(
        "x-plain" to plainX(),
        "x-thin" to thinX(),
        "x-circle" to xInCircle(filled = false),
        "x-circle-filled" to xInCircle(filled = true),
        "x-square" to xInSquare(filled = false),
        "x-square-filled" to xInSquare(filled = true),
    )

    private fun make(draw: (Canvas) -> Unit): Bitmap {
        val b = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawColor(Color.WHITE)
        draw(c)
        return b
    }

    private fun stroke(width: Float, color: Int = Color.BLACK): Paint {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.STROKE
        p.strokeWidth = width
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.color = color
        return p
    }

    private fun fill(color: Int): Paint {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.FILL
        p.color = color
        return p
    }

    private fun Canvas.drawX(from: Float, to: Float, p: Paint) {
        drawLine(from, from, to, to, p)
        drawLine(to, from, from, to, p)
    }

    private fun plainX() = make { c -> c.drawX(26f, 70f, stroke(9f)) }

    private fun thinX() = make { c -> c.drawX(28f, 68f, stroke(4f)) }

    private fun xInCircle(filled: Boolean) = make { c ->
        if (filled) {
            c.drawCircle(48f, 48f, 40f, fill(Color.rgb(70, 70, 70)))
            c.drawX(33f, 63f, stroke(7f, Color.WHITE))
        } else {
            c.drawCircle(48f, 48f, 40f, stroke(5f))
            c.drawX(33f, 63f, stroke(7f))
        }
    }

    private fun xInSquare(filled: Boolean) = make { c ->
        if (filled) {
            c.drawRoundRect(RectF(10f, 10f, 86f, 86f), 14f, 14f, fill(Color.rgb(70, 70, 70)))
            c.drawX(32f, 64f, stroke(7f, Color.WHITE))
        } else {
            c.drawRoundRect(RectF(14f, 14f, 82f, 82f), 10f, 10f, stroke(5f))
            c.drawX(32f, 64f, stroke(6f))
        }
    }
}
