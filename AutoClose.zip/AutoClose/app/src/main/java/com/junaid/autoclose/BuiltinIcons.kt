package com.junaid.autoclose

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF

/**
 * বিজ্ঞাপনে সাধারণত যেসব ক্লোজ (×) ও স্কিপ (>>) আইকন দেখা যায়,
 * তার কয়েকটা ধরন কোড দিয়ে আঁকা হয়। মেলানো হয় আইকনের আউটলাইন (edge) ধরে,
 * তাই আইকন কালো না সাদা, তাতে সমস্যা হয় না।
 */
object BuiltinIcons {

    private const val S = 96

    fun all(): List<Pair<String, Bitmap>> = listOf(
        "x-plain" to plainX(),
        "x-circle" to xInCircle(filled = false),
        "x-circle-filled" to xInCircle(filled = true),
        "x-square-filled" to xInSquare(),
        "chevrons" to chevrons(),
        "chevrons-circle" to chevronsInCircle(),
        "skip-ad" to skipAd(),
    )

    private fun make(draw: (Canvas) -> Unit): Bitmap {
        val b = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawColor(Color.WHITE)
        draw(c)
        return b
    }

    private fun stroke(width: Float, color: Int = Color.BLACK) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = width
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        this.color = color
    }

    private fun fill(color: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        this.color = color
    }

    private fun Canvas.drawX(from: Float, to: Float, p: Paint) {
        drawLine(from, from, to, to, p)
        drawLine(to, from, from, to, p)
    }

    private fun plainX() = make { c ->
        c.drawX(26f, 70f, stroke(9f))
    }

    private fun xInCircle(filled: Boolean) = make { c ->
        if (filled) {
            c.drawCircle(48f, 48f, 40f, fill(Color.rgb(70, 70, 70)))
            c.drawX(33f, 63f, stroke(7f, Color.WHITE))
        } else {
            c.drawCircle(48f, 48f, 40f, stroke(5f))
            c.drawX(33f, 63f, stroke(7f))
        }
    }

    private fun xInSquare() = make { c ->
        c.drawRoundRect(RectF(10f, 10f, 86f, 86f), 14f, 14f, fill(Color.rgb(70, 70, 70)))
        c.drawX(32f, 64f, stroke(7f, Color.WHITE))
    }

    private fun chevronPath(p: Path, x: Float, y: Float, w: Float, h: Float) {
        p.moveTo(x, y)
        p.lineTo(x + w, y + h / 2)
        p.lineTo(x, y + h)
    }

    private fun chevrons() = make { c ->
        val p = Path()
        chevronPath(p, 20f, 26f, 24f, 44f)
        chevronPath(p, 48f, 26f, 24f, 44f)
        c.drawPath(p, stroke(9f))
    }

    private fun chevronsInCircle() = make { c ->
        c.drawCircle(48f, 48f, 40f, stroke(5f))
        val p = Path()
        chevronPath(p, 30f, 34f, 14f, 28f)
        chevronPath(p, 48f, 34f, 14f, 28f)
        c.drawPath(p, stroke(7f))
    }

    /** ▶▶| — ভিডিও বিজ্ঞাপনের "Skip" আইকন */
    private fun skipAd() = make { c ->
        val f = fill(Color.BLACK)
        val t1 = Path().apply {
            moveTo(14f, 26f); lineTo(14f, 70f); lineTo(44f, 48f); close()
        }
        val t2 = Path().apply {
            moveTo(44f, 26f); lineTo(44f, 70f); lineTo(74f, 48f); close()
        }
        c.drawPath(t1, f)
        c.drawPath(t2, f)
        c.drawRect(RectF(76f, 26f, 84f, 70f), f)
    }
}
