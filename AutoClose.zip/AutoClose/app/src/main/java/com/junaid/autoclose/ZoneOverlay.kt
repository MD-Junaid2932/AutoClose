package com.junaid.autoclose

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import kotlin.math.max
import kotlin.math.min

/**
 * ১) pick(): পুরো স্ক্রিন জুড়ে হালকা কালো পর্দা, আঙুল টেনে একটা আয়তক্ষেত্র (জোন) বেছে নেওয়া যায়।
 * ২) flash(): সেট করা জোনগুলো কিছুক্ষণ রঙিন বর্ডারসহ দেখায় (ছোঁয়া যায় না)।
 * দুটোই Accessibility overlay, তাই আলাদা অনুমতি লাগে না।
 */
class ZoneOverlay(private val ctx: Context) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val density: Float = ctx.resources.displayMetrics.density

    private var pickRoot: View? = null
    private var flashRoot: View? = null
    private val clearRunnable = Runnable { clearFlash() }
    private var pickFinished = false

    /** সার্ভিস বন্ধ হলে সব ওভারলে সরিয়ে দেয় */
    fun clearAll() {
        pickFinished = true
        finishPick()
        clearFlash()
    }

    private fun fullScreenParams(touchable: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) {
            p.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return p
    }

    // ---------- জোন বেছে নেওয়া ----------

    /** onDone: বাছা আয়তক্ষেত্র (স্ক্রিনের পিক্সেলে), বাতিল করলে null। মেইন থ্রেডে ডাকা হয়। */
    fun pick(index: Int, onDone: (Rect?) -> Unit) {
        finishPick()
        clearFlash()
        pickFinished = false

        val frame = FrameLayout(ctx)
        val view = PickView(ctx, "জোন $index: আঙুল টেনে এলাকা বেছে নিন") { rect ->
            handler.post {
                if (!pickFinished) {
                    pickFinished = true
                    finishPick()
                    onDone(rect)
                }
            }
        }
        frame.addView(
            view,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )

        val cancel = Button(ctx)
        cancel.text = "বাতিল"
        cancel.setOnClickListener {
            handler.post {
                if (!pickFinished) {
                    pickFinished = true
                    finishPick()
                    onDone(null)
                }
            }
        }
        val lp = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        )
        lp.gravity = Gravity.TOP or Gravity.END
        lp.topMargin = (48 * density).toInt()
        lp.rightMargin = (12 * density).toInt()
        frame.addView(cancel, lp)

        try {
            wm.addView(frame, fullScreenParams(true))
            pickRoot = frame
        } catch (e: Exception) {
            pickRoot = null
            onDone(null)
        }
    }

    private fun finishPick() {
        val v = pickRoot
        pickRoot = null
        if (v != null) {
            try {
                wm.removeView(v)
            } catch (e: Exception) {
            }
        }
    }

    // ---------- জোন দেখানো ----------

    fun flash(zones: List<Pair<Int, Rect>>, ms: Long) {
        clearFlash()
        if (zones.isEmpty()) return
        val v = FlashView(ctx, zones)
        try {
            wm.addView(v, fullScreenParams(false))
            flashRoot = v
        } catch (e: Exception) {
            flashRoot = null
            return
        }
        handler.removeCallbacks(clearRunnable)
        handler.postDelayed(clearRunnable, ms)
    }

    fun clearFlash() {
        handler.removeCallbacks(clearRunnable)
        val v = flashRoot
        flashRoot = null
        if (v != null) {
            try {
                wm.removeView(v)
            } catch (e: Exception) {
            }
        }
    }

    // ---------- ভিউ ----------

    private class PickView(
        context: Context,
        private val label: String,
        private val onResult: (Rect?) -> Unit
    ) : View(context) {

        private val d: Float = context.resources.displayMetrics.density
        private val dim = Paint()
        private val fillP = Paint()
        private val border = Paint()
        private val textP = Paint()
        private val loc = IntArray(2)
        private var sx = 0f
        private var sy = 0f
        private var ex = 0f
        private var ey = 0f
        private var dragging = false

        init {
            dim.color = Color.argb(120, 0, 0, 0)
            fillP.color = Color.argb(60, 255, 193, 7)
            border.color = Color.rgb(255, 193, 7)
            border.style = Paint.Style.STROKE
            border.strokeWidth = 3f * d
            textP.color = Color.WHITE
            textP.textSize = 16f * d
            textP.isAntiAlias = true
        }

        override fun onDraw(canvas: Canvas) {
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dim)
            canvas.drawText(label, 16f * d, 90f * d, textP)
            if (dragging) {
                getLocationOnScreen(loc)
                val l = min(sx, ex) - loc[0]
                val t = min(sy, ey) - loc[1]
                val r = max(sx, ex) - loc[0]
                val b = max(sy, ey) - loc[1]
                canvas.drawRect(l, t, r, b, fillP)
                canvas.drawRect(l, t, r, b, border)
            }
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX
                    sy = e.rawY
                    ex = sx
                    ey = sy
                    dragging = true
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    ex = e.rawX
                    ey = e.rawY
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    ex = e.rawX
                    ey = e.rawY
                    dragging = false
                    invalidate()
                    val r = Rect(
                        min(sx, ex).toInt(), min(sy, ey).toInt(),
                        max(sx, ex).toInt(), max(sy, ey).toInt()
                    )
                    val minSize = (24 * d).toInt()
                    // খুব ছোট হলে ধরে নিই ভুল করে ছুঁয়েছে, আবার চেষ্টা করা যাবে
                    if (r.width() >= minSize && r.height() >= minSize) onResult(r)
                    return true
                }
                MotionEvent.ACTION_CANCEL -> {
                    dragging = false
                    invalidate()
                    return true
                }
            }
            return super.onTouchEvent(e)
        }
    }

    private class FlashView(
        context: Context,
        private val zones: List<Pair<Int, Rect>>
    ) : View(context) {

        private val d: Float = context.resources.displayMetrics.density
        private val border = Paint()
        private val fillP = Paint()
        private val textP = Paint()
        private val loc = IntArray(2)
        private val colors = intArrayOf(
            Color.rgb(255, 193, 7), Color.rgb(3, 169, 244), Color.rgb(233, 30, 99)
        )

        init {
            border.style = Paint.Style.STROKE
            border.strokeWidth = 3f * d
            textP.textSize = 18f * d
            textP.isAntiAlias = true
            textP.isFakeBoldText = true
        }

        override fun onDraw(canvas: Canvas) {
            getLocationOnScreen(loc)
            for (z in zones) {
                val c = colors[(z.first - 1).coerceIn(0, colors.size - 1)]
                val r = z.second
                val l = (r.left - loc[0]).toFloat()
                val t = (r.top - loc[1]).toFloat()
                val rr = (r.right - loc[0]).toFloat()
                val b = (r.bottom - loc[1]).toFloat()
                fillP.color = Color.argb(40, Color.red(c), Color.green(c), Color.blue(c))
                canvas.drawRect(l, t, rr, b, fillP)
                border.color = c
                canvas.drawRect(l, t, rr, b, border)
                textP.color = c
                canvas.drawText(z.first.toString(), l + 6f * d, t + 22f * d, textP)
            }
        }
    }
}
